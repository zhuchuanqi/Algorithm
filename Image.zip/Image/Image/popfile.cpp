
#include<stdio.h>
#include <windows.h>
#include <commdlg.h>

static OPENFILENAME ofn ;

void PopFileInitialize (HWND hwnd)
{
	static TCHAR szFilter[] = 		
		TEXT ("All Files (*.*)\0*.*\0\0") \
		TEXT ("Text Files (*.bmp)\0*.bmp\0") \
		TEXT ("ASCII Files (*.raw)\0*.raw\0") \
		TEXT ("ASCII Files (*.dcm)\0*.dcm\0") \
		TEXT ("ASCII Files (*.3dr)\0*.3dr\0") ;		
	ofn.lStructSize = sizeof (OPENFILENAME) ;
	ofn.hwndOwner = hwnd ;
	ofn.hInstance = NULL ;
	ofn.lpstrFilter = szFilter ;
	ofn.lpstrCustomFilter = NULL ;
	ofn.nMaxCustFilter = 0 ;
	ofn.nFilterIndex = 0 ;
	ofn.lpstrFile = NULL ; // Set in Open and Close functions
	ofn.nMaxFile = MAX_PATH ;
	ofn.lpstrFileTitle = NULL ; // Set in Open and Close functions
	ofn.nMaxFileTitle = MAX_PATH ;
	ofn.lpstrInitialDir = NULL ;
	ofn.lpstrTitle = NULL ;
	ofn.Flags = 0 ; // Set in Open and Close functions
	ofn.nFileOffset = 0 ;
	ofn.nFileExtension = 0 ;
	ofn.lpstrDefExt = TEXT ("*") ;
	ofn.lCustData = 0L ;
	ofn.lpfnHook = NULL ;
	ofn.lpTemplateName = NULL ;
}

BOOL PopFileOpenDlg (HWND hwnd, PTSTR pstrFileName, PTSTR pstrTitleName)
{
	ofn.hwndOwner = hwnd ;
	ofn.lpstrFile = pstrFileName ;
	ofn.lpstrFileTitle = pstrTitleName ;
	ofn.Flags = OFN_HIDEREADONLY | OFN_CREATEPROMPT ;
	return GetOpenFileName (&ofn) ;
}
BOOL PopFileSaveDlg (HWND hwnd, PTSTR pstrFileName, PTSTR pstrTitleName)
{
	ofn.hwndOwner = hwnd ;
	ofn.lpstrFile = pstrFileName ;
	ofn.lpstrFileTitle = pstrTitleName ;
	ofn.Flags = OFN_OVERWRITEPROMPT ;
	return GetSaveFileName (&ofn) ;
}
////�����@���І��}
//BOOL PopImageRead(PTSTR pstrFileName, int width, int height,int bits, PWORD *wdImageData,int &iMax, int iImage){	
//	SetCursor(LoadCursor(NULL, IDC_WAIT));
//	DWORD dwBytesRead ;
//	HANDLE hFile ;
//	int iFileLength ;  //�ļ�����
//	
//	//pBuffer������2���ֽ�
//	PWORD pBuffer = NULL;
//	// Open the file.
//	if (INVALID_HANDLE_VALUE ==
//		(hFile = CreateFile (pstrFileName, GENERIC_READ,
//		FILE_SHARE_READ,
//		NULL, OPEN_EXISTING, 0, NULL)))
//		return FALSE ;
//	// Get file size in bytes and allocate memory for read.
//	// Add an extra two bytes for zero termination.
//	iFileLength = GetFileSize (hFile, NULL) ;
//	//if(pBuffer) free(pBuffer);
//	BYTE *byTemp = (BYTE *)malloc(height * width);
//	pBuffer = (PWORD) malloc (width * height * sizeof(WORD)) ;
//	// Read file and put terminating zeros at end.
//	//int realWidth = (bits == 8 ? width : 2 * width ); 
//	int i,j, max = 0;	
//
//	SetFilePointer(hFile, width * height * (bits / 8) * iImage, NULL, FILE_BEGIN);
//	/*if(bits == 16){
//		for(i = 0; i < height; i ++)
//			for(j = 0; j < width; j ++){
//				ReadFile(hFile, &byte1, 1, &dwBytesRead, NULL);	
//				ReadFile(hFile, &byte2, 1, &dwBytesRead, NULL);				
//				pBuffer[ i * width + j] = ((WORD)byte2 << 8 | byte1);
//				if(pBuffer[i * width + j] > max)
//					max = pBuffer[i * width + j];
//			}
//	}*/
//	if(bits == 16)
//		ReadFile(hFile, pBuffer, width * height * 2, &dwBytesRead, NULL);	
//	else if(bits == 8){
//		ReadFile(hFile, byTemp, width * height, &dwBytesRead, NULL);
//		for(i = 0; i < height; i ++)
//			for(j = 0; j < width; j ++){
//				pBuffer[i * width + j] = byTemp[i * height + j];				
//			}
//	}
//	for(i = 0; i < height; ++ i)
//		for(j = 0; j < width; ++ j){
//			if(pBuffer[i * width + j] > max)
//				max = pBuffer[ i * width + j];
//		}
//	//��Ҫ�õ����ֵ����һ��
//	CloseHandle (hFile) ;	
//	*wdImageData = pBuffer;
//	iMax = max;
//	SetCursor(LoadCursor(NULL, IDC_ARROW));
//	return TRUE;
//}
//BOOL PopFileRead (HWND hwndEdit, PTSTR pstrFileName, PBYTE data)
//{
//	BYTE bySwap ;
//	DWORD dwBytesRead ;
//	HANDLE hFile ;
//	int i, iFileLength, iUniTest ;
//	PBYTE pBuffer, pText, pConv ;
//	// Open the file.
//	if (INVALID_HANDLE_VALUE ==
//		(hFile = CreateFile (pstrFileName, GENERIC_READ,
//		FILE_SHARE_READ,
//		NULL, OPEN_EXISTING, 0, NULL)))
//		return FALSE ;
//	// Get file size in bytes and allocate memory for read.
//	// Add an extra two bytes for zero termination.
//	iFileLength = GetFileSize (hFile, NULL) ;
//	pBuffer = (BYTE *)malloc (iFileLength + 2) ;
//	// Read file and put terminating zeros at end.
//	ReadFile (hFile, pBuffer, iFileLength, &dwBytesRead, NULL) ;
//	CloseHandle (hFile) ;
//	pBuffer[iFileLength] = '\0' ;
//	pBuffer[iFileLength + 1] = '\0' ;
//	// Test to see if the text is Unicode
//	iUniTest = IS_TEXT_UNICODE_SIGNATURE |
//		IS_TEXT_UNICODE_REVERSE_SIGNATURE ;
//	if (IsTextUnicode (pBuffer, iFileLength, &iUniTest))
//	{
//		pText = pBuffer + 2 ;
//		iFileLength -= 2 ;
//		if (iUniTest & IS_TEXT_UNICODE_REVERSE_SIGNATURE)
//		{
//			for (i = 0 ; i < iFileLength / 2 ; i++)
//			{
//				bySwap = ((BYTE *) pText) [2 * i] ;
//				((BYTE *) pText) [2 * i] = ((BYTE *) pText) [2 * i + 1] ;
//				((BYTE *) pText) [2 * i + 1] = bySwap ;
//			}
//		}
//		// Allocate memory for possibly converted string
//		pConv = (BYTE *)malloc (iFileLength + 2) ;
//
//		// If the edit control is not Unicode, convert Unicode text to
//		// non-Unicode (i.e., in general, wide character).
//#ifndef UNICODE
//		WideCharToMultiByte (CP_ACP, 0, (PWSTR) pText, -1, pConv,
//			iFileLength + 2, NULL, NULL) ;
//		// If the edit control is Unicode, just copy the
//		string
//#else
//		lstrcpy ((PTSTR) pConv, (PTSTR) pText) ;
//#endif
//	}
//	else // the file is not Unicode
//	{
//		pText = pBuffer ;
//		// Allocate memory for possibly converted string.
//		pConv = (BYTE *)malloc (2 * iFileLength + 2) ;
//		// If the edit control is Unicode, convert ASCII text.
//#ifdef UNICODE
//		MultiByteToWideChar (CP_ACP, 0, (LPCSTR)pText, -1, (PTSTR) pConv,
//			iFileLength + 1) ;
//		// If not, just copy buffer
//#else
//		lstrcpy ((PTSTR) pConv, (PTSTR) pText) ;
//#endif
//	}
//
//	SetWindowText (hwndEdit, (PTSTR) pConv) ;
//	free (pBuffer) ;
//	free (pConv) ;
//	return TRUE ;
//}
//BOOL PopFileWrite (HWND hwndEdit, PTSTR pstrFileName)
//{
//	DWORD dwBytesWritten ;
//	HANDLE hFile ;
//	int iLength ;
//	PTSTR pstrBuffer ;
//	WORD wByteOrderMark = 0xFEFF ;
//	// Open the file, creating it if necessary
//	if (INVALID_HANDLE_VALUE ==
//		(hFile = CreateFile (pstrFileName, GENERIC_WRITE, 0,
//		NULL, CREATE_ALWAYS, 0, NULL)))
//		return FALSE ;
//	// Get the number of characters in the edit control and allocate
//	// memory for them.
//	iLength = GetWindowTextLength (hwndEdit) ;
//	pstrBuffer = (PTSTR) malloc ((iLength + 1) * sizeof (TCHAR)) ;
//	if (!pstrBuffer)
//	{
//		CloseHandle (hFile) ;
//		return FALSE ;
//	}
//	// If the edit control will return Unicode text, write the
//	// byte order mark to the file.
//#ifdef UNICODE
//	WriteFile (hFile, &wByteOrderMark, 2, &dwBytesWritten, NULL) ;
//#endif
//	// Get the edit buffer and write that out to the file.
//	GetWindowText (hwndEdit, pstrBuffer, iLength + 1) ;
//	WriteFile (hFile, pstrBuffer, iLength * sizeof (TCHAR),
//		&dwBytesWritten, NULL) ;
//	if ((iLength * sizeof (TCHAR)) != (int) dwBytesWritten)
//	{
//		CloseHandle (hFile) ;
//		free (pstrBuffer) ;
//		return FALSE ;
//	}
//	CloseHandle (hFile) ;
//	free (pstrBuffer) ;
//	return TRUE ;
//}
