#include <windows.h>
#include <commdlg.h>
#include <math.h>
#include <iostream>
using namespace std;
#define PI 3.14159
#define E 2.71828
#define MAXVALUE 65535
#define NLM_WINDOW_RADIUS   10
#define NLM_BLOCK_RADIUS    3
#define NLM_WINDOW_AREA     ( (2 * NLM_WINDOW_RADIUS + 1) * (2 * NLM_WINDOW_RADIUS + 1) )
#define INV_NLM_WINDOW_AREA ( 1.0f / (float)NLM_WINDOW_AREA )
#define NLM_WEIGHT_THRESHOLD    0.10f
#define NLM_LERP_THRESHOLD      0.10f
// ��ȡ�����ı�׼�� noise standard deviation
// block��ָ�ָ�������С��һ��ȡ8 ��ʾ 8 * 8 ��С  
extern "C"
int NSD(WORD *wdImageData, int width, int height, int block){
	//������Ч������Բ�Σ���������֪ʶҪ���뾶���ȵ�90%��ȥ��
	int hBlocks = height * 0.9 / block; 
	int wBlocks = width  * 0.9 / block;
	int hStart = height / 2 * 0.1;
	int wStart = width / 2 * 0.1;
	const int BARSCOUNT = 200;
	double minLSD = MAXVALUE, meanLSD, topValue;//�ֲ���׼����Сֵ���ֲ���׼���ֵ �� �ָ������Ͻ�
	double LM, chaZhi, sumLSD = 0;
	double *LSDs = new double[hBlocks * wBlocks]();
	int counts[BARSCOUNT]={0};//��ʾ150�������У�0- 199 �ֱ����һ���Ҽ���Χ����ֵ��ʾ��������Ҷȼ���Χ�����صĸ���
	int indexLSD = 0, majorLSDCount, iNSD; 
	int square = block * block - 1;
	int effectiveSquareCount = 0;
	for(int i = 0; i < hBlocks; i ++)
		for(int j = 0; j < wBlocks; j ++){
			double sum = 0;		
			if(wdImageData[(i * block + hStart) * width + (j * block + wStart)] == 0) continue;
			for(int m = i * block + hStart; m < (i + 1) * block + hStart; m ++)
				for(int n = j * block + wStart; n < (j + 1) * block + wStart; n ++){
					sum += wdImageData[m * width + n];
					LM = sum / (block * block);
				}				
			for(int m = i * block + hStart; m < (i + 1) * block + hStart; m ++)
				for(int n = j * block + wStart; n < (j + 1) * block + wStart; n ++){
					chaZhi = LM - wdImageData[m * width + n];
					sum += chaZhi * chaZhi;
				}
			effectiveSquareCount ++;
			LSDs[i * wBlocks + j] = sqrt(sum / square);
			if( LSDs[i * wBlocks + j] != 0 && LSDs[i * wBlocks + j] < minLSD) 
				minLSD = LSDs[i * wBlocks + j];
			sumLSD += LSDs[i * wBlocks + j];
			
		}
	meanLSD = sumLSD / effectiveSquareCount;
	topValue = 112 * meanLSD;//�õ��ָ�������Ͻ�
	double span = topValue / BARSCOUNT;
	for(int i = 0; i < hBlocks; i ++)
		for(int j = 0; j < wBlocks; j ++){
			int temp = LSDs[i * wBlocks + j];
			if(temp - 0 <1E-6) continue;
			counts[(int)(temp / span)] ++;
		}
	majorLSDCount = counts[0];

	for(int i = 0; i < BARSCOUNT; i++)
		if(majorLSDCount < counts[i]){
			majorLSDCount = counts[i];
			indexLSD = i;
		}
	double majorLSDSum = 0;
	double majorSpanLow = indexLSD * span, majorSpanHigh = (indexLSD + 1) * span;
	for(int i = 0; i < hBlocks; i ++)
		for(int j = 0; j < wBlocks; j ++){
			if(LSDs[i * wBlocks + j] >= majorSpanLow && LSDs[i * wBlocks + j] < majorSpanHigh)
				majorLSDSum += LSDs[i * wBlocks + j];
		}
	iNSD = majorLSDSum / majorLSDCount;
	return iNSD;
}
double Index(int i, int j, double sigmaK, int k){
       return -((i-k-1) * (i-k-1) + (j-k-1) * (j-k-1)) / (2 * sigmaK * sigmaK);
}
double Formula(int i,int j, double sigmaK, int k){
	  return pow(E, Index(i, j, sigmaK, k)) * 1 / (2 * PI * sigmaK * sigmaK); 	  	 
}
double** Fspecial(int size, double sigmaK, int k){//�õ���˹��
      if(!(size % 2)) return NULL;
	  int semiSize = size / 2;	 
	  double **filter = new double*[size];
	  for(int i = 0;i < size;i ++){
	       filter[i] = new double[size];
	  }
	  for(int i = 0; i < size; i ++){
		  for(int j = 0; j < size; j ++){
		         filter[i][j] = Formula(i-semiSize, j-semiSize, sigmaK, k);
		  }
	  }
	  //���й�һ������
	  double sum = 0;
	  for(int i = 0;i < semiSize;i ++){
		  for(int j = i;j <= semiSize;j ++){
			  if((j == i)||(j == semiSize && (i != semiSize))){
				  sum += filter[i][j] * 4;
			  }			  			  
			  else sum += filter[i][j] * 8;
		  }		
	  }
	  sum += filter[semiSize][semiSize];
	  for(int i = 0;i < size;i ++)
		  for(int j = 0; j < size; j ++)
			  filter[i][j] = floor(filter[i][j] / sum * 10000) / 10000;
		  /*for(i=0;i<size;i++){
		      for(int j=0;j<size;j++)
			      cout<<filter[i][j]<<",";
			  cout<<endl;
		  }*/
	  return filter;	  
}
//�˴����ܶ��ھ���Ȩ�ص�ŷ����þ���������е�ƫ��
double EuclideanDist(WORD * wdImageData, int width, int height, int i1, int j1, int i2, int j2){
	float dist = 0;
	int vi, vj, i, j; //����ĳ�����ص�ֵ
	for(i = -3; i <= 3 ; ++ i)
		for(j = -3; j <= 3; ++ j){
			vi = wdImageData[(i1 + i) * width + j1 + j];
			vj = wdImageData[(i2 + i) * width + j2 + j];			
			dist += (vi - vj) * (vi - vj);
		}
	return dist;
}
float lerpf_slow(float a, float b, float c)
{
	return a + (b - a) * c;
}

extern "C"
void NLMeans_cpu(PWORD *wdImageData, int width, int height, float Noise, float lerpC){
	WORD * resultImageData = new WORD[width * height]();
	//double ** filter = Fspecial(sizeK, sigmaK, k);		
	double sum = 0, d;	
	for(int i = 21; i < height - 21; i++)
		for(int j = 21; j < width - 21; j++){
			sum = 0;
			double result = 0;
			float fCount = 0;
			for(int m = i - 10; m < i + 10; m ++)
				for(int n = j - 10; n < j + 10; n ++){
					d = EuclideanDist(*wdImageData, width, height, i, j, m, n);
					float ed = exp(-(d * Noise + ((m - i) * (m - i) + (n - j) * (n - j)) * INV_NLM_WINDOW_AREA));
					result += (*wdImageData)[m * width + n] * ed;
					sum += ed;
					fCount      += (ed > NLM_WEIGHT_THRESHOLD) ? INV_NLM_WINDOW_AREA : 0;					
				}	
				result = result / sum;
				float lerpQ = (fCount > NLM_LERP_THRESHOLD) ? lerpC : 1.0f - lerpC;
				float result0 = resultImageData[i * width + j];
				result = result + (result0 - result) * lerpQ;
				resultImageData[i * width + j] = result;
		}
		//��֮ǰռ�õĿռ���ͷ�Ȼ�����·���ռ䣬
		delete (*wdImageData);
		(*wdImageData) = resultImageData;
}