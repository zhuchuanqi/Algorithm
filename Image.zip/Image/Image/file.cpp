#include<iostream>
#include"file.h"
#include <tchar.h>
using namespace std;
void File::FileToBmp(PWORD* wdImageData, TCHAR* szDestFileName){
	PureDataFileRead(wdImageData);
	BYTE *byImageData = Nomalization(*wdImageData);
	WriteToBmpFile(szDestFileName, byImageData);
}
BOOL File::WriteToBmpFile(TCHAR* szDestFileName, BYTE *byImgData)
{
	int i, j;
	BYTE black = 0;
	int width = baseInfo.width;
	int height = baseInfo.height;
	/*fseek(fp,sizeof(WORD)+sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER),SEEK_SET);*/	
	int jump = 0;
	switch(width % 4)
	{
	case 0:jump = 0;break;
	case 1:jump = 3;break;
	case 2:jump = 2;break;
	case 3:jump = 1;break;	
	}
	DWORD bfSize = (width  + jump) * height + 256 * 4 + 54;   // λͼ�ļ��Ĵ�С�����ֽ�Ϊ��λ width * height * 3 + 54(Ҫ��֤width ������4�ı���)
	WORD bfReserved1 = 0;  // λͼ�ļ������֣�����Ϊ0
	WORD bfReserved2 = 0;  // λͼ�ļ������֣�����Ϊ0
	DWORD   bfOffBits = 256 * 4 + 54; // λͼ���ݵ���ʼλ�ã��������λͼ��54
	fileHeader.bfSize = bfSize;
	fileHeader.bfReserved1 = bfReserved1;
	fileHeader.bfReserved2 = bfReserved2;
	fileHeader.bfOffBits = bfOffBits;

	DWORD  biSize = 40;   // ���ṹ��ռ���ֽ���: 40
	LONG biWidth  = width;  // λͼ�Ŀ��ȣ�������Ϊ��λ
	LONG biHeight = height; // λͼ�ĸ߶ȣ�������Ϊ��λ
	WORD biPlanes = 1; // Ŀ���豸�ļ��𣬱���Ϊ1
	WORD biBitCount = 8;// ÿ�����������λ����������1(˫ɫ)//Ӧ����24λ
	// 4(16ɫ)��8(256ɫ)��24(���ɫ)֮һ
	DWORD  biCompression = 0;   // λͼѹ�����ͣ������� 0(��ѹ��)���������˼
	// 1(BI_RLE8ѹ������)��2(BI_RLE4ѹ������)֮һ
	//�����24λλͼ��һ����8bit��Ҫ���ó�0
	DWORD  biSizeImage = 0; // λͼ�Ĵ�С�����ֽ�Ϊ��λ   ����λͼ�ļ��Ĵ�С��λͼ�Ĵ�С�� width * height * 3 + 54
	LONG biXPelsPerMeter = 0; // λͼˮƽ�ֱ��ʣ�ÿ��������:  3780
	LONG biYPelsPerMeter = 0;  // λͼ��ֱ�ֱ��ʣ�ÿ��������: 3780
	DWORD  biClrUsed = 0;// λͼʵ��ʹ�õ���ɫ���е���ɫ����0
	DWORD  biClrImportant = 0;// λͼ��ʾ��������Ҫ����ɫ����0
	

	infoHeader.biSize = biSize;
	infoHeader.biWidth = biWidth;
	infoHeader.biHeight = biHeight;	
	infoHeader.biPlanes = biPlanes;
	infoHeader.biBitCount = biBitCount;
	infoHeader.biCompression = biCompression;
	infoHeader.biSizeImage = biSizeImage;
	infoHeader.biXPelsPerMeter = biXPelsPerMeter;
	infoHeader.biYPelsPerMeter = biYPelsPerMeter;
	infoHeader.biClrUsed = biClrUsed;
	infoHeader.biClrImportant = biClrImportant;	


	BYTE type[2] = {0x42, 0x4D};	
	if(hFile) 
		FindClose(hFile);
	if(INVALID_HANDLE_VALUE == (hFile = CreateFile(szDestFileName, GENERIC_WRITE , FILE_SHARE_READ, NULL, OPEN_ALWAYS, 0, NULL))){
		//TRACE(_T("Can't open file %s, error = %u\n"), bmpFileName);
		return FALSE;
	}
	/*if(!cFile.Open(bmpFileName, CStdioFile::modeWrite | CStdioFile::modeCreate | CStdioFile::typeBinary, &cException)){
	TRACE(_T("Can't open file %s, error = %u\n"), bmpFileName, cException.m_cause);
	return FALSE;
	}*/
	DWORD dwBytesRead;
	WriteFile(hFile, &type, 2, &dwBytesRead, FALSE);
	SetFilePointer(hFile, 2, NULL, FILE_BEGIN);
	WriteFile(hFile, &fileHeader, sizeof(MYBITMAPFILEHEADER), &dwBytesRead, FALSE);
	SetFilePointer(hFile, 14, NULL, FILE_BEGIN);
	WriteFile(hFile, &infoHeader, sizeof(BITMAPINFOHEADER), &dwBytesRead, FALSE);	
	SetFilePointer(hFile, 54, NULL, FILE_BEGIN);
	RGBQUAD rgbQUAD[256];
	for(i = 0; i < 256; i ++){
		rgbQUAD[i].rgbBlue = i;
		rgbQUAD[i].rgbGreen = i;
		rgbQUAD[i].rgbRed = i;
		rgbQUAD[i].rgbReserved = 0;
	}
	WriteFile(hFile, &rgbQUAD, 256 * 4, &dwBytesRead, FALSE);
	BYTE * byImgDataTemp = NULL;
	if(jump){
		int newWidth = width + jump;
		byImgDataTemp = (BYTE *)malloc(newWidth * height);
		for(i = 0; i < height; i ++){
			for(j = 0; j < width; j ++)
				byImgDataTemp[i * newWidth + j] = byImgData[(height - i - 1) * width + j];	
			for(j = width; j < newWidth; j ++)
				byImgDataTemp[i * newWidth + j] = 0;
		}
	}
	else{
		//byImgDataTemp = byImgData;
		byImgDataTemp = (BYTE *)malloc(width * height);
		for(i = 0; i < height; i ++)
			for(j = 0; j < width; j ++)
				byImgDataTemp[i * width + j] = byImgData[(height - i - 1) * width + j];	
	}
	SetFilePointer(hFile, 54 + 256 * 4, NULL, FILE_BEGIN);
	WriteFile(hFile, byImgDataTemp, (width + jump) * height, &dwBytesRead, FALSE);
	//SetFilePointer(hFile, 54 + 256 * 4 + (width + jump) * height, NULL, FILE_BEGIN);
	//����Ҫ��һ���ļ���β��
	SetEndOfFile(hFile);

	CloseHandle(hFile);
	free(byImgData);
	byImgData = NULL;
	//if(jump)
	free(byImgDataTemp);
	byImgDataTemp = NULL;
	return TRUE;
}
/*
	��ȡ��Ϊ������8bits λͼ��ʽ�� 16bitsλͼ��ʽ
*/
BOOL File::BmpFileRead(BYTE** wdImageData){
	int i, j;	
	DWORD dwBytesRead;
	BYTE head[2] = {0x00};	
	if(hFile) FindClose(hFile);
	if(INVALID_HANDLE_VALUE == (hFile = CreateFile(baseInfo.szFileName, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_ALWAYS, 0, NULL)))
		return FALSE;
	ReadFile(hFile, head, 2, &dwBytesRead, NULL);
	if(head[0] != 0x42 || head[1] != 0x4D){
		//TRACE("%s ����λͼ�ļ���", baseInfo.szFileName);
		return FALSE;
	}
	MYBITMAPFILEHEADER fileHeader;
	BITMAPINFOHEADER infoHeader;
	ReadFile(hFile, &fileHeader, sizeof(MYBITMAPFILEHEADER), &dwBytesRead, NULL);
	ReadFile(hFile, &infoHeader, sizeof(BITMAPINFOHEADER), &dwBytesRead, NULL);
	BYTE *byBufferTemp = NULL;	
	BYTE *pBuffer = NULL;
	int bits = infoHeader.biBitCount;
	int width = infoHeader.biWidth;
	int height = infoHeader.biHeight;
	baseInfo.width = width;
	baseInfo.height = height;
	baseInfo.bits = bits;

	int jump = 0, newWidth;
	pBuffer = (BYTE *)malloc(width * height);
	//��ʱ����һ����
	if(bits == 8){
		switch(width % 4){
		case 0:jump = 0;break;
		case 1:jump = 3;break;
		case 2:jump = 2;break;
		case 3:jump = 1;break;	
		}
		newWidth = width + jump;
		byBufferTemp = (BYTE *)malloc(newWidth * height);
		SetFilePointer(hFile, 54 + 256 * 4, NULL, FILE_BEGIN);		
	}
	else if(bits == 24){
		switch(width * 3 % 4){
		case 0:jump = 0;break;
		case 1:jump = 3;break;
		case 2:jump = 2;break;
		case 3:jump = 1;break;	
		}
		newWidth = width * 3 + jump;
		byBufferTemp = (BYTE *)malloc(newWidth * height);		
		SetFilePointer(hFile, 54, NULL, FILE_BEGIN);
	}
	else{
		//AfxMessageBox("��֧�ֳ���256ɫ�Լ�24���ɫ������λͼ��ʽ��");
		return FALSE;
	}
	ReadFile(hFile, byBufferTemp, newWidth * height, &dwBytesRead, NULL);	
	if(bits == 8){
		for(i = 0; i < height; i ++)
			for(j = 0; j < width; j ++)
				pBuffer[i * width + j] = byBufferTemp[(height - i - 1) * newWidth + j];			
	}else if(bits == 24){
		for(i = 0; i < height; i ++)
			for(j = 0; j < width; j++)
				pBuffer[i * width + j] = byBufferTemp[(height - i - 1) * newWidth + 3 * j];
	}
	(*wdImageData) = pBuffer;
	free(byBufferTemp);
	byBufferTemp = NULL;
	CloseHandle(hFile);
	return TRUE;
}
BOOL File::PureDataFileRead(PWORD *wdImageData){	
	SetCursor(LoadCursor(NULL, IDC_WAIT));
	DWORD dwBytesRead ;	
	int width = baseInfo.width;
	int height = baseInfo.height;
	int iFileLength ;  //
	//pBuffer������2���ֽ�
	PWORD pBuffer = NULL;
	// Open the file.
	if(hFile) FindClose(hFile);
	if (INVALID_HANDLE_VALUE ==
		(hFile = CreateFile (baseInfo.szFileName, GENERIC_READ,
		FILE_SHARE_READ,
		NULL, OPEN_ALWAYS, 0, NULL)))
		return FALSE ;
	// Get file size in bytes and allocate memory for read.
	// Add an extra two bytes for zero termination.
	iFileLength = GetFileSize (hFile, NULL) ;
	//if(pBuffer) free(pBuffer);
	BYTE *byTemp = (BYTE *)malloc(height * width);
	pBuffer = (PWORD) malloc (width * height * sizeof(WORD)) ;
	// Read file and put terminating zeros at end.
	//int realWidth = (bits == 8 ? width : 2 * width ); 
	int i,j, max = 0;	
	int bits = baseInfo.bits;
	SetFilePointer(hFile, width * height * (bits / 8) * baseInfo.imgIndex, NULL, FILE_BEGIN);
	/*if(bits == 16){
		for(i = 0; i < height; i ++)
			for(j = 0; j < width; j ++){
				ReadFile(hFile, &byte1, 1, &dwBytesRead, NULL);	
				ReadFile(hFile, &byte2, 1, &dwBytesRead, NULL);				
				pBuffer[ i * width + j] = ((WORD)byte2 << 8 | byte1);
				if(pBuffer[i * width + j] > max)
					max = pBuffer[i * width + j];
			}
	}*/
	if(bits == 16)
		ReadFile(hFile, pBuffer, width * height * 2, &dwBytesRead, NULL);	
	else if(bits == 8){
		ReadFile(hFile, byTemp, width * height, &dwBytesRead, NULL);
		for(i = 0; i < height; i ++)
			for(j = 0; j < width; j ++){
				pBuffer[i * width + j] = byTemp[i * height + j];				
			}
	}
	for(i = 0; i < height; ++ i)
		for(j = 0; j < width; ++ j){
			if(pBuffer[i * width + j] > max)
				max = pBuffer[ i * width + j];
		}
	//��Ҫ�õ����ֵ����һ��
	free(byTemp);
	byTemp = NULL;
	CloseHandle (hFile) ;	
	*wdImageData = pBuffer;
	baseInfo.maxPixel = max;
	SetCursor(LoadCursor(NULL, IDC_ARROW));
	return TRUE;
}
BYTE* File::Nomalization(PWORD wdImageData){
	//HDC hdc = GetDC(hwnd);
	int windowCenter = baseInfo.windowCenter;
	int windowWidth = baseInfo.windowWidth;
	int imgWidth = baseInfo.width;
	int imgHeight = baseInfo.height;
	if(!wdImageData) return NULL;
	BYTE *byImageData = (BYTE *)malloc(imgWidth * imgHeight);
	int windowLow, windowHigh,currentValue;
	if(baseInfo.fileType == DCM){
		windowLow = windowCenter - windowWidth / 2;
		windowHigh = windowCenter + windowWidth / 2;		
		for(int i = 0; i < imgWidth; i++)
			for(int j = 0; j < imgHeight; j++){				  
				currentValue = wdImageData[i * imgWidth + j];
				if(currentValue >= windowLow && currentValue <= windowHigh){
					byImageData[i * imgWidth + j] = (double)(currentValue -  windowLow) / windowWidth * 255;
				}
				else if(currentValue < windowLow)
					byImageData[i * imgWidth + j] = 0;
				else 
					byImageData[i * imgWidth + j] = 255;
			}
	}
	else{
		int maxPixel = baseInfo.maxPixel;
		for(int i = 0; i < imgWidth; i++)
			for(int j = 0; j < imgHeight; j++){	
				byImageData[i * imgWidth + j] = (double)wdImageData[i * imgWidth + j] / maxPixel * 255;
			}
	}
	return byImageData;

}