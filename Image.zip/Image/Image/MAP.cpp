#include<stdlib.h>
#include<math.h>
#define MAP_WINDOW_RADIUS_2 2
#define MAP_WINDOW_RADIUS_3 3
#define MAP_WINDOW_SIZE_2 ((MAP_WINDOW_RADIUS_2 * 2 + 1)* (MAP_WINDOW_RADIUS_2 * 2 + 1))
#define MAP_WINDOW_SIZE_3 ((MAP_WINDOW_RADIUS_3 * 2 + 1)* (MAP_WINDOW_RADIUS_3 * 2 + 1))
const float THRESHOLD = 0.1;
typedef unsigned short WORD;
float GetSigma(WORD *wdImageData, int width, int height, int row, int col, int meanValue)
{
	if(row < MAP_WINDOW_RADIUS_3 || row > height - MAP_WINDOW_RADIUS_3 || col < MAP_WINDOW_RADIUS_3 || col > width - MAP_WINDOW_RADIUS_3)
		return -1;
	float sum = 0;
	int rowStart = row - MAP_WINDOW_RADIUS_2, rowEnd = row + MAP_WINDOW_RADIUS_2;
	int colStart = col - MAP_WINDOW_RADIUS_2, colEnd = col + MAP_WINDOW_RADIUS_2;
	for(int i = rowStart; i <= rowEnd; ++ i)	
		for(int j = colStart; j <= colEnd; ++ j){
			int currentValue = wdImageData[i * width + j];
			sum += (currentValue - meanValue) * (currentValue - meanValue);
		}
		sum /= (MAP_WINDOW_SIZE_2 - 1);
		return sum - meanValue > 0 ? sum - meanValue : 0;
}
float GetFij(float fij, float sigma, float gij)
{
	return ((fij - sigma) + sqrt((fij - sigma) * (fij - sigma) + 4 * sigma * gij))/ 2;
}
float GetParameter_3(WORD *wdImageData, int width, int height, int row, int col, float *meanValue)
{
	if(row < MAP_WINDOW_RADIUS_3 || row > height - MAP_WINDOW_RADIUS_3 || col < MAP_WINDOW_RADIUS_3 || col > width - MAP_WINDOW_RADIUS_3)
		return -1;
	float sum = 0, sigmaf = 0.0f, afa, sigmag = 0.0f;
	int rowStart = row - MAP_WINDOW_RADIUS_3, rowEnd = row + MAP_WINDOW_RADIUS_3;
	int colStart = col - MAP_WINDOW_RADIUS_3, colEnd = col + MAP_WINDOW_RADIUS_3;
	for(int i = rowStart; i <= rowEnd; ++ i)	
		for(int j = colStart; j <= colEnd; ++ j){
			sum += wdImageData[i * width + j];
		}
	(*meanValue) = sum / MAP_WINDOW_SIZE_3;
	sum = 0;
	for(int i = rowStart; i <= rowEnd; ++ i)	
		for(int j = colStart; j <= colEnd; ++ j){
			int currentValue = wdImageData[i * width + j];
			sum += (currentValue - *meanValue) * (currentValue - *meanValue);
		}
	sigmag  = sum / (MAP_WINDOW_SIZE_3 - 1);
	return  (sigmag - *meanValue > 0 ? sigmag - *meanValue : 0);			
}
float GetParameter_2(WORD *wdImageData, int width, int height, int row, int col, float *meanValue)
{
	if(row < MAP_WINDOW_RADIUS_3 || row > height - MAP_WINDOW_RADIUS_3 || col < MAP_WINDOW_RADIUS_3 || col > width - MAP_WINDOW_RADIUS_3)
		return -1;
	float sumFM = 0, sigmaf = 0.0f, afa, sigmag = 0.0f;
	int rowStart = row - MAP_WINDOW_RADIUS_2, rowEnd = row + MAP_WINDOW_RADIUS_2;
	int colStart = col - MAP_WINDOW_RADIUS_2, colEnd = col + MAP_WINDOW_RADIUS_2;
	for(int i = rowStart; i <= rowEnd; ++ i)	
		for(int j = colStart; j <= colEnd; ++ j){
			sumFM += wdImageData[i * width + j];
		}
    *meanValue = sumFM / MAP_WINDOW_SIZE_2;
	float sumFS = 0;
	for(int i = rowStart; i <= rowEnd; ++ i)	
		for(int j = colStart; j <= colEnd; ++ j){
			int currentValue = wdImageData[i * width + j];
			sumFS += (currentValue - *meanValue) * (currentValue - *meanValue);
		}
	sigmag  = sumFS / (MAP_WINDOW_SIZE_2 - 1);
	sigmaf = (sigmag - *meanValue > 0 ? sigmag - *meanValue : 0);
	if(sigmag != 0){
		afa = sigmaf / sigmag;
		if(afa < THRESHOLD){
			sigmaf = GetParameter_3(wdImageData, width, height, row, col, meanValue);
		}		
	}
	return sigmaf;
}
float GetMeanValue(WORD *wdImageData, int width, int height, int row, int col)
{
	if(row < MAP_WINDOW_RADIUS_3 || row > height - MAP_WINDOW_RADIUS_3 || col < MAP_WINDOW_RADIUS_3 || col > width - MAP_WINDOW_RADIUS_3)
		return -1;
	float sum = 0;
	int rowStart = row - MAP_WINDOW_RADIUS_2, rowEnd = row + MAP_WINDOW_RADIUS_2;
	int colStart = col - MAP_WINDOW_RADIUS_2, colEnd = col + MAP_WINDOW_RADIUS_2;
	//Ĭ�ϵĴ��ڴ�С��5 * 5
	for(int i = rowStart; i <= rowEnd; ++ i)	
		for(int j = colStart; j <= colEnd; ++ j){
			sum += wdImageData[i * width + j];
		}
	return sum / MAP_WINDOW_SIZE_2;
}

extern "C"
void MAP(WORD **wdImageData, int width, int height)
{
	WORD *result = (WORD *)malloc(width * height * sizeof(WORD));
	//memset(result, 0, width * height * sizeof(WORD));
	for(int i = 0; i < height; ++ i)
		for(int j = 0; j < width; ++ j){
			
			if(i < MAP_WINDOW_RADIUS_3 || i > height - MAP_WINDOW_RADIUS_3 || j < MAP_WINDOW_RADIUS_3 || j > width - MAP_WINDOW_RADIUS_3){
				result[i * width + j] = 0;
			}
			else {
				float meanvalue = 0.0f, sigmaf = 0.0f;
				sigmaf = GetParameter_2(*wdImageData, width, height, i, j, &meanvalue);		
				result[i * width + j] = GetFij(meanvalue, sigmaf, (*wdImageData)[i * width + j]);
				/*	float fij = GetMeanValue(*wdImageData, width, height, i, j);
				float sigma = GetSigma(*wdImageData, width, height, i, j, fij);
				result[i * width + j] = GetFij(fij, sigma, (*wdImageData)[i * width + j]);*/
			}
		}
	free(*wdImageData);
	(*wdImageData) = result;	
}