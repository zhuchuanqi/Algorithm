#include<math.h>
typedef unsigned short WORD;
typedef float (*R)[3];
#define inf 65536
#define PI 3.14159
#define E 2.71828
#define MAXVALUE 65535
#define NLM_WINDOW_RADIUS   10
#define NLM_BLOCK_RADIUS    3
#define NLM_WINDOW_AREA     ( (2 * NLM_WINDOW_RADIUS + 1) * (2 * NLM_WINDOW_RADIUS + 1) )
#define INV_NLM_WINDOW_AREA ( 1.0f / (float)NLM_WINDOW_AREA )
#define NLM_WEIGHT_THRESHOLD    0.10f
#define NLM_LERP_THRESHOLD      0.10f
//extern "C"
//double EuclideanDist(WORD * wdImageData, int width, int height, int i1, int j1, int i2, int j2);
void get_segmentseeds(WORD *wdImageData, int width, int height, float segmentseeds[][3], int expected_sp_number, int &superpixel_number_real)
{
	float superpixel_size = float(width * height) / expected_sp_number;
	float superpixel_step = floor(sqrt(superpixel_size) + 0.5);
	int width_strips = width / superpixel_step + 1;
	int height_strips = height / superpixel_step + 1;
	float width_err = width - superpixel_step * width_strips;
	if(width_err < 0){
		width_strips = width_strips - 1;
		width_err = width - superpixel_step * width_strips;
	}
	float height_err = height - height_strips * superpixel_step;
	if(height_err < 0){
		height_strips -= 1;
		height_err = height - superpixel_step * height_strips;
	}
	float width_errperstrip = (float)width_err / width_strips;
	float height_errperstrip = (float)height_err / height_strips;
	//segmentseeds ����ʢ�ų�ʼ���ӵ㣬Ҫ�з���ֵ
	/*int segmentseeds = new int*[expected_sp_number];
	for(int i = 0; i < expected_sp_number; ++ i){
	segmentseeds[i] = new int[3]();
	}*/
	float width_off = superpixel_step / 2;
	float height_off = superpixel_step / 2;
	int  seed_index = 0;
	for(int j = 1; j <= width_strips; ++ j){
		float width_e = (j - 1) * width_errperstrip;
		int seed_j = floor((j - 1) * superpixel_step + width_off + width_e);
		for(int i = 1; i <= height_strips; ++ i){
			float height_e = (i - 1) * height_errperstrip;
			int seed_i = floor((i - 1) * superpixel_step + height_off + height_e);
			int seed_intensity = wdImageData[(seed_i - 1) * width + seed_j -1];
			segmentseeds[seed_index][0] = seed_i - 1;
			segmentseeds[seed_index][1] = seed_j - 1;
			segmentseeds[seed_index][2] = seed_intensity;
			seed_index ++;                                                                                                                                                               
		}
	}	
	superpixel_number_real = seed_index;
}
void get_segment_label(WORD *wdImageData, int width, int height, int expected_sp_number, 
	int *segment_label, float segmentseeds[][3], int superpixel_number_real, int iterC, int weight)
{
	//m_weight��ɶ�����أ� 	
	int error_threshold = expected_sp_number * 0.1;
	float superpixel_size = float(width * height) / expected_sp_number;
	float superpixel_square = floor((sqrt(superpixel_size) + 0.5) / 2);
	float *pixel_distance = new float[width * height]();
	for(int i = 0; i < width * height; ++ i)
		pixel_distance[i] = inf;
	R i_segmentseeds = new float[superpixel_number_real][3];
	for(int iter = 0; iter < iterC; ++ iter){
		for(int m = 0; m < superpixel_number_real; ++ m){
			int seed_i = segmentseeds[m][0] ;
			int seed_j = segmentseeds[m][1] ;
			int seed_intensity = segmentseeds[m][2];
			int i_left = seed_i - superpixel_square * 2;
			int i_right = seed_i + superpixel_square * 2;
			int j_left = seed_j - superpixel_square * 2;
			int j_right = seed_j + superpixel_square * 2;
			i_left = (i_left > 0 ? i_left : 0);
			i_right = (i_right > height -1 ? height - 1 : i_right);
			j_left = (j_left > 0 ? j_left : 0);
			j_right = (j_right > width - 1 ? width - 1: j_right);
			for(int pixel_j = j_left; pixel_j <= j_right; ++ pixel_j)
				for(int pixel_i = i_left; pixel_i <= i_right; ++ pixel_i){
					int pixel_intensity = wdImageData[pixel_i * width + pixel_j];
					float distance_spatial = sqrt(float((seed_i - pixel_i) * (seed_i - pixel_i) + (seed_j - pixel_j) * (seed_j - pixel_j)));
					int distance_intensity = abs(seed_intensity - pixel_intensity);
					float distance_np = distance_intensity + distance_spatial * weight / superpixel_square;
					if(distance_np < pixel_distance[pixel_i * width + pixel_j]){
						pixel_distance[pixel_i * width + pixel_j] = distance_np;
						segment_label[pixel_i * width + pixel_j] = m;
					}
				}
		}	
		int *sigma_i = new int[superpixel_number_real]();
		int *sigma_j = new int[superpixel_number_real]();
		int *sigma_intensity = new int[superpixel_number_real]();
		int *sigma_pixelnumber = new int[superpixel_number_real]();
		for(int pixel_i = 0; pixel_i < height; ++ pixel_i)
			for(int pixel_j = 0; pixel_j < width; ++ pixel_j){
				int pixel_label = segment_label[pixel_i * width + pixel_j];
				int pixel_intensity = wdImageData[pixel_i * width + pixel_j];
				sigma_i[pixel_label] += pixel_i; 
				sigma_j[pixel_label] += pixel_j; 
				sigma_intensity[pixel_label] += pixel_intensity;
				sigma_pixelnumber[pixel_label] ++;
			}
		for(int i = 0; i < superpixel_number_real; ++ i)
			if(sigma_pixelnumber[i] < 1)
				sigma_pixelnumber[i] = 1;
		//����sigmaseeds
		
		for(int i = 0; i < superpixel_number_real; ++ i){
			i_segmentseeds[i][0] = segmentseeds[i][0];
			i_segmentseeds[i][1] = segmentseeds[i][1];
			i_segmentseeds[i][2] = segmentseeds[i][2];
		}
		for(int i = 0; i < superpixel_number_real; ++ i){
			int number = sigma_pixelnumber[i];
			i_segmentseeds[i][0] = (int)((float)sigma_i[i] / number + 0.5);
			i_segmentseeds[i][1] = (int)((float)sigma_j[i] / number + 0.5);
			i_segmentseeds[i][2] = (float)sigma_intensity[i] / number;
		}	
		int i_seederrorsum = 0;
		for(int i = 0; i < superpixel_number_real; ++ i){
			i_seederrorsum += (abs(i_segmentseeds[i][0] - segmentseeds[i][0]) + abs(i_segmentseeds[i][1] - segmentseeds[i][1]));
		}
		for(int i = 0; i < superpixel_number_real; ++ i){
			segmentseeds[i][0] = i_segmentseeds[i][0];
			segmentseeds[i][1] = i_segmentseeds[i][1];
			segmentseeds[i][2] = i_segmentseeds[i][2];
		}
		if(i_seederrorsum < error_threshold)
			break;
		delete[]sigma_i;
		delete[]sigma_j;
		delete[]sigma_intensity;
		delete[]sigma_pixelnumber;
		

	}	
	delete[] i_segmentseeds;
	delete[] pixel_distance;
}
double EuclideanDist_NA(WORD * wdImageData, int width, int height, int i1, int j1, int i2, int j2){
	float dist = 0;
	int vi, vj, i, j; //����ĳ�����ص�ֵ
	for(i = -3; i <= 3 ; ++ i)
		for(j = -3; j <= 3; ++ j){
			vi = wdImageData[(i1 + i) * width + j1 + j];
			vj = wdImageData[(i2 + i) * width + j2 + j];			
			dist += (vi - vj) * (vi - vj);
		}
		return dist;
}
void enforce_connectivity(int *segment_label, int width, int height, int expected_sp_number, int *new_segment_label)
{
	int superpixel_size = (width * height) / expected_sp_number;
	int dx4[] = {-1, 0, 1, 0};
	int dy4[] = {0, -1, 0, 1};
	int *pixel_i_vec = new int[width * height]();
	int *pixel_j_vec = new int[width * height]();
	int adj_label = 1;
	int label = 1;
	int pixel_count = 0;	
	for(int pixel_j = 0; pixel_j < width; ++ pixel_j)
		for(int pixel_i = 0; pixel_i < height; ++ pixel_i){
			if(new_segment_label[pixel_i * width + pixel_j] < 1){
				new_segment_label[pixel_i * width + pixel_j] = label;
				pixel_i_vec[0] = pixel_i;
				pixel_j_vec[0] = pixel_j;
				for(int n = 0; n < 4; ++ n){
					int pixel_x = pixel_i_vec[0] + dx4[n];
					int pixel_y = pixel_j_vec[0] + dy4[n];
					if(pixel_x >= 0 && pixel_x < height && pixel_y >= 0 && pixel_y < width)
						if(new_segment_label[pixel_x * width + pixel_y] >= 1)
							adj_label = new_segment_label[pixel_x * width + pixel_y];
				}
				pixel_count = 0;
				int c = 0;
				while(c <= pixel_count){
					for(int n = 0; n < 4; ++ n){
						int  pixel_x = pixel_i_vec[c] + dx4[n];
						int  pixel_y = pixel_j_vec[c] + dy4[n];
						if(pixel_x >= 0 && pixel_x < height  && pixel_y >= 0 && pixel_y < width)
							if(new_segment_label[pixel_x * width + pixel_y] < 1 && segment_label[pixel_x * width + pixel_y] == segment_label[pixel_i * width + pixel_j]){
								pixel_count ++;
								pixel_i_vec[pixel_count] = pixel_x;
								pixel_j_vec[pixel_count] = pixel_y;
								new_segment_label[pixel_x * width + pixel_y] = label;
							}
					}
					c ++;
				}
				//�����и�round
				if(pixel_count < (superpixel_size / 2)){
					for(c = 0; c < pixel_count; ++ c)
						new_segment_label[width * pixel_i_vec[c] + pixel_j_vec[c]] = adj_label;
					label --;
				}
				label ++;
			}
		}
		delete[]pixel_i_vec;
		delete[]pixel_j_vec; 
}
void draw_segment_label(WORD *wdImageData, int width, int height, int *segment_label)
{
	for(int i = 1; i < width - 1; ++ i)
		for(int j = 1; j < height - 1; ++ j){
			int label_left = segment_label[j  * width + i - 1];
			int label_right = segment_label[j  * width + i + 1];
			int label_up = segment_label[(j - 1) * width + i];
			int label_down = segment_label[(j + 1) * width + i];
			if(label_left != label_right || label_up != label_down)
				wdImageData[j * width + i] = 50;
		}
	delete []segment_label;
}
         
extern "C"
void SLIC(WORD **wdImagedata, int width, int height, int expected_sp_number, int iterC, int weight)
{	
	R segment_seeds;
	segment_seeds = new float[expected_sp_number][3];
	int superpixel_number_real = 0;
	int *segment_label = new int[width * height]();
	get_segmentseeds(*wdImagedata, width, height, segment_seeds, expected_sp_number, superpixel_number_real);
	get_segment_label(*wdImagedata, width,height, expected_sp_number, segment_label, segment_seeds, superpixel_number_real, iterC, weight);
	int *new_segment_label = new int[width * height]();
	for(int i = 0; i < width * height; ++ i)
		new_segment_label[i] = -1;
	enforce_connectivity(segment_label, width, height, expected_sp_number, new_segment_label);
	draw_segment_label(*wdImagedata, width, height, new_segment_label);
	//delete[] new_segment_label;
}

extern "C"
void NLM_SLIC(WORD **wdImageData, int width, int height, int expected_sp_number, int iterC, int weight, 
	float Noise, float lerpC){	
	R segment_seeds;
	segment_seeds = new float[expected_sp_number][3];
	int superpixel_number_real = 0;
	int *segment_label = new int[width * height]();
	get_segmentseeds(*wdImageData, width, height, segment_seeds, expected_sp_number, superpixel_number_real);
	get_segment_label(*wdImageData, width,height, expected_sp_number, segment_label, segment_seeds, superpixel_number_real, iterC, weight);
	int *new_segment_label = new int[width * height]();
	for(int i = 0; i < width * height; ++ i)
		new_segment_label[i] = -1;
	enforce_connectivity(segment_label, width, height, expected_sp_number, new_segment_label);
	WORD * resultImageData = new WORD[width * height]();
	//double ** filter = Fspecial(sizeK, sigmaK, k);		
	double sum = 0.0f, d;	
	for(int i = 21; i < height - 21; i++)
		for(int j = 21; j < width - 21; j++){
			sum = 0.0f;
			double result = 0.0f;
			float fCount = 0;	
			for(int m = i - 10; m < i + 10; m ++)
				for(int n = j - 10; n < j + 10; n ++){
					int ij_label_left = new_segment_label[i  * width + j - 1];
					int ij_label_right = new_segment_label[i  * width + j + 1];
					int ij_label_up = new_segment_label[(i - 1) * width + j];
					int ij_label_down = new_segment_label[(i + 1) * width + j];

					int mn_label_left = new_segment_label[m  * width + n - 1];
					int mn_label_right = new_segment_label[m  * width + n + 1];
					int mn_label_up = new_segment_label[(m - 1) * width + n];
					int mn_label_down = new_segment_label[(m + 1) * width + n];
					float ed = 0.0;
					if((ij_label_left == mn_label_left && ij_label_right == mn_label_right) ||
						(ij_label_up == mn_label_up && ij_label_down == mn_label_down)){
						d = EuclideanDist_NA(*wdImageData, width, height, i, j, m, n);
						ed = exp(-(d * Noise + ((m - i) * (m - i) + (n - j) * (n - j)) * INV_NLM_WINDOW_AREA));
					}else
						ed = 0;
					result += (*wdImageData)[m * width + n] * ed;
					sum += ed;
					fCount  += (ed > NLM_WEIGHT_THRESHOLD) ? INV_NLM_WINDOW_AREA : 0;					
				}	
				//�����Գ�һ��label�Ĺ�����
				
				result = result / sum;
				
				float lerpQ = (fCount > NLM_LERP_THRESHOLD) ? lerpC : 1.0f - lerpC;
				float result0 = resultImageData[i * width + j];
				result = result + (result0 - result) * lerpQ;
				if(result < 40.0f){
					result = ((*wdImageData)[(i - 1) * width + j] + (*wdImageData)[(i + 1) * width + j] + (*wdImageData)[i * width + j - 1] +
						(*wdImageData)[i * width + j + 1]) / 4;
				}
				resultImageData[i * width + j] = result;
		}
		//��֮ǰռ�õĿռ���ͷ�Ȼ�����·���ռ�
		delete (*wdImageData);
		(*wdImageData) = resultImageData;
}
extern "C"
void NLM_SLIC1(WORD **wdImageData, int width, int height, int expected_sp_number, int iterC, int weight, 
float Noise, float lerpC){	
	R segment_seeds;
	segment_seeds = new float[expected_sp_number][3];
	int superpixel_number_real = 0;
	int *segment_label = new int[width * height]();
	get_segmentseeds(*wdImageData, width, height, segment_seeds, expected_sp_number, superpixel_number_real);
	get_segment_label(*wdImageData, width,height, expected_sp_number, segment_label, segment_seeds, superpixel_number_real, iterC, weight);
	int *new_segment_label = new int[width * height]();
	for(int i = 0; i < width * height; ++ i)
		new_segment_label[i] = -1;
	enforce_connectivity(segment_label, width, height, expected_sp_number, new_segment_label);
	WORD * resultImageData = new WORD[width * height]();
	//double ** filter = Fspecial(sizeK, sigmaK, k);
	double sum = 0, d;	
	for(int i = 21; i < height - 21; i++)
		for(int j = 21; j < width - 21; j++){
			sum = 0;
			double result = 0;
			float fCount = 0;	
			for(int m = i - 10; m < i + 10; m ++)
				for(int n = j - 10; n < j + 10; n ++){
					int ij_label_left = new_segment_label[i  * width + j - 1];
					int ij_label_right = new_segment_label[i  * width + j + 1];
					int ij_label_up = new_segment_label[(i - 1) * width + j];
					int ij_label_down = new_segment_label[(i + 1) * width + j];

					int mn_label_left = new_segment_label[m  * width + n - 1];
					int mn_label_right = new_segment_label[m  * width + n + 1];
					int mn_label_up = new_segment_label[(m - 1) * width + n];
					int mn_label_down = new_segment_label[(m + 1) * width + n];
					float ed = 0.0;
					if((ij_label_left == mn_label_left && ij_label_right == mn_label_right) ||
						(ij_label_up == mn_label_up && ij_label_down == mn_label_down)){
							d = EuclideanDist_NA(*wdImageData, width, height, i, j, m, n);
							ed = exp(-(d * Noise + ((m - i) * (m - i) + (n - j) * (n - j)) * INV_NLM_WINDOW_AREA));
					}else
						ed = 0;
					result += (*wdImageData)[m * width + n] * ed;
					sum += ed;
					fCount  += (ed > NLM_WEIGHT_THRESHOLD) ? INV_NLM_WINDOW_AREA : 0;					
				}					
				if(sum - 0 < 0.000001){
					sum = (resultImageData[(i - 1) * width + j] + resultImageData[(i + 1) * width + j] + resultImageData[i * width + j - 1] +
						resultImageData[i * width + j + 1]) / 4;
				}
				result = result / sum;
				float lerpQ = (fCount > NLM_LERP_THRESHOLD) ? lerpC : 1.0f - lerpC;
				float result0 = resultImageData[i * width + j];
				result = result + (result0 - result) * lerpQ;
				resultImageData[i * width + j] = result;
		}
		//��֮ǰռ�õĿռ���ͷ�Ȼ�����·���ռ�
		delete (*wdImageData);
		(*wdImageData) = resultImageData;
}

//double EuclideanDist(WORD * wdImageData, int width, int height, int i1, int j1, int i2, int j2){
//	float dist = 0;
//	int vi, vj, i, j; //����ĳ�����ص�ֵ
//	for(i = -3; i <= 3 ; ++ i)
//		for(j = -3; j <= 3; ++ j){
//			vi = wdImageData[(i1 + i) * width + j1 + j];
//			vj = wdImageData[(i2 + i) * width + j2 + j];			
//			dist += (vi - vj) * (vi - vj);
//		}
//		return dist;
//}
extern "C"
void M_SLIC(WORD **wdImagedata, int width, int height, int expected_sp_number, int iterC, int weight)
{
	/*WORD *wdImageDataCopy = new WORD[width * height]();
	for(int i = 0; i < height; ++ i)
	for(int j = 0; j < width; ++ j){
	wdImageDataCopy[i * width + j] = (*wdImagedata)[(height - i - 1) * width + j]; 
	}
	delete (*wdImagedata);
	(*wdImagedata) = wdImageDataCopy;	*/
	R segment_seeds;
	segment_seeds = new float[expected_sp_number][3];
	int superpixel_number_real = 0;
	int *segment_label = new int[width * height]();
	get_segmentseeds(*wdImagedata, width, height, segment_seeds, expected_sp_number, superpixel_number_real);
	get_segment_label(*wdImagedata, width,height, expected_sp_number, segment_label, segment_seeds, superpixel_number_real, iterC, weight);
	int *new_segment_label = new int[width * height]();
	for(int i = 0; i < width * height; ++ i)
		new_segment_label[i] = -1;
	enforce_connectivity(segment_label, width, height, expected_sp_number, new_segment_label);
	int *pixel_count = new int[expected_sp_number]();
	int *pixel_value = new int[expected_sp_number]();
	for(int i = 0; i < height; ++ i)
		for(int j = 0; j < width; ++ j){
			int label = new_segment_label[i * width + j];
			pixel_count[label] ++;
			pixel_value[label] += (*wdImagedata)[i * width + j];
		}
	for(int i = 0; i < height; ++ i)
		for(int j = 0; j < width; ++ j){
			int label = new_segment_label[i * width + j];
			(*wdImagedata)[i * width + j] = pixel_value[label] / pixel_count[label];
		}
}