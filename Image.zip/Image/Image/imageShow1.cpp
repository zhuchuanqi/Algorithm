#include <windows.h>
#include "resource.h"
#include "dicom.h"
#include "file.h"
#include<math.h>
#include <tchar.h>
#include <crtdbg.h>
#include<time.h>
#define UNTITLED TEXT ("(untitled)")


static float nlmNoise = 2.0f;
static float    lerpC = 0.2f;
static TCHAR szAppName[] = TEXT ("ImageShow") ;
TCHAR szTempFileName[] = _T("D:\\bitmap.bmp");
int imgWidth = 1024, imgHeight = 1024;
int windowCenter, windowWidth;
int bits = 16;
int iImage = 0 ;


HMENU hMenu;


//self-define method
void PopFileInitialize (HWND hwnd);
BOOL PopFileOpenDlg (HWND hwnd, PTSTR pstrFileName, PTSTR pstrTitleName);
BOOL PopFileSaveDlg (HWND hwnd, PTSTR pstrFileName, PTSTR pstrTitleName);
//һ��Ҫ������״̬
extern "C" void  NLMeans(PWORD wdImageData, int width, int height, float Noise, float lerpC);
extern "C" void  QNLMeans(PWORD wdImageData, int width, int height, float Noise, float lerpC);
extern "C" void  NLMeans_cpu(PWORD *wdImageData, int width, int height, float Noise, float lerpC);	
extern "C" void MAP(WORD **wdImageData, int width, int height);
extern "C" int NSD(WORD *wdImageData, int width, int height, int block);
extern "C"
void SLIC(WORD **wdImagedata, int width, int height, int expected_sp_number, int iterC, int weight);
//���̴�������
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK AboutDlgProc(HWND hwndDlg, UINT message, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK ImageAttrDlgProc(HWND hwndDlg, UINT message, WPARAM wParam, LPARAM lParam);
void NLM_SLIC(WORD **wdImagedata, int width, int height, int expected_sp_number, int iterC, int weight,
	float Noise, float lerpC);


void GetWindowWH(int *width, int *height){
	*width = GetSystemMetrics(SM_CXSCREEN);
	*height = GetSystemMetrics(SM_CYSCREEN);
}
//���ڴӶԻ����н��շ�����Ϣ
//typedef struct {
//	int width; //��ͼ��Ŀ���
//	int height;//��ͼ��ĸ߶�
//	int bits;  //ÿ��ͼ��ռ�ݵ�����λ��
//}IMAGEATTR;
int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance,  PSTR  szCmdLine,  int iCmdShow)  
{
	static TCHAR           szAppName[] = TEXT ("head") ; 
	HWND hwnd ; 
	MSG msg ; 
	WNDCLASS                              wndclass ;  
	wndclass.style= CS_HREDRAW  | CS_VREDRAW ;  
	wndclass.lpfnWndProc                  = WndProc ;  
	wndclass.cbClsExtra                   = 0 ;  
	wndclass.cbWndExtra                   = 0 ;  
	wndclass.hInstance                    = hInstance ;  
	wndclass.hIcon = LoadIcon (hInstance, MAKEINTRESOURCE(IDI_ICON1));  
	wndclass.hCursor= LoadCursor  (NULL, 
		IDC_ARROW) ;  
	//�ѱ���ѡΪ��ɫ�Ļ�ˢ 
	wndclass.hbrBackground= (HBRUSH)GetStockObject(WHITE_BRUSH);
	wndclass.lpszMenuName                 = NULL ;  
	wndclass.lpszClassName                = szAppName ;  
	if (!RegisterClass (&wndclass))  
	{ 
		MessageBox  (NULL,  TEXT  ("This  program  requires  Windows NT!"),  
			szAppName, MB_ICONERROR) ;  
		return 0 ; 
	} 	
	hMenu = LoadMenu(hInstance, MAKEINTRESOURCE(IDR_MENU1));
	int cxWidth, cyHeight;
	GetWindowWH(&cxWidth, &cyHeight);
	hwnd = CreateWindow (szAppName, TEXT ("ImageShow 1.0"),  
		WS_OVERLAPPEDWINDOW,  
		0, 0,  
		cxWidth, cyHeight,  
		NULL, hMenu, hInstance, NULL) ;  
	ShowWindow (hwnd, iCmdShow) ;  
	UpdateWindow (hwnd) ; 
	while (GetMessage (&msg, NULL, 0, 0))  
	{ 
		TranslateMessage (&msg) ;  
		DispatchMessage (&msg) ;  
	} 
	return msg.wParam ;  
}  
FILETYPE FileType(TCHAR *szFileName){
	if(szFileName == NULL)
		return OTHERS;
	TCHAR *pBeg = szFileName;
	while(*pBeg ++ != '\0');	
	while(*pBeg -- != TCHAR('.'));
	pBeg += 2;
	if(lstrcmp(pBeg, TEXT("bmp")) == 0 || lstrcmp(pBeg, TEXT("BMP")) == 0)
		return BMP;
	else if(lstrcmp(pBeg, TEXT("raw")) == 0 || lstrcmp(pBeg, TEXT("RAW")) == 0)
		return RAW;
	else if(lstrcmp(pBeg, TEXT("dcm")) == 0 || lstrcmp(pBeg, TEXT("DCM")) == 0)
		return DCM;
	else if(lstrcmp(pBeg, TEXT("3dr")) == 0 || lstrcmp(pBeg, TEXT("3DR")) == 0)
		return THREEDR;
	else
		return OTHERS;
} 
void OkMessage (HWND hwnd, TCHAR * szMessage, TCHAR * szTitleName)
{
	TCHAR szBuffer[64 + MAX_PATH] ;
	wsprintf (szBuffer, szMessage, szTitleName[0] ? szTitleName :
		UNTITLED) ;
	MessageBox (hwnd, szBuffer, szAppName, MB_OK |
		MB_ICONEXCLAMATION) ;
}
void DoCaption (HWND hwnd, TCHAR * szTitleName)
{
	TCHAR szCaption[64 + MAX_PATH] ;
	wsprintf (szCaption, TEXT ("%s - %s"), szAppName,
		szTitleName[0] ? szTitleName : UNTITLED) ;
	SetWindowText (hwnd, szCaption) ;
}
//���������ݷ�Χ���ܻᳬ��256����������ʾ��ʱ��Ҫ���й�һ����������ʱ���ܹ�һ������
//����������Ͳ����������Ҫ˵�ǻ������⣬����ǻ������⣬�Ǳ��˵ĳ���Ϊʲô���ܵ���ô�ã�
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam){
	HINSTANCE hInstance;
	static HDC hdc, hdcMem;
	PAINTSTRUCT ps;
	static RECT rcImage, rcLogo;	
	static HWND hwndScroll, hwndValue, hwndULMeans, hwndMAP, hwndSLIC, hwndMSLIC;
	static int cxWidth, cyHeight;
	static TCHAR szFileName[MAX_PATH], szTitleName[MAX_PATH];
	static HBITMAP hBitmap;
	BITMAP bitmap;	
	File file;
	static FILETYPE fileType;
	TCHAR szBuffer[10];	
	static int iMax = 0;//�������ݵ����ֵ��������һ�� 0~255
	static int cxChar, cyChar;
	DicomHandler dicomHandler;
	static PWORD  wdImageData = NULL;
	static BYTE* byImageData = 0x00;	
	int k = -1;
	//��˹�˱�׼��
	double sigmaK = 1.2;
	//��˹�����ı�׼��
	int sigmaN;
	int h, i, j;
	static int maxPixel = 0;
	unsigned int sizeK = 7;	
	static FILEBASEINFO baseInfo;
	static HWND hwndScrollImage;//�����϶�3drͼ��
	clock_t start, stop;
	//�����ֿ�Ĵ�С
	static int expected_sp_number = 700;
	static int iterC = 10;
	//�������ϵĳ̶�
	static int weight = 10;
	switch(message){		
	case WM_CREATE:
		cxChar = LOWORD (GetDialogBaseUnits ()) ;
		cyChar = HIWORD (GetDialogBaseUnits ()) ;
		hdc = GetDC(hwnd);
		GetWindowWH(&cxWidth, &cyHeight);	
		//��ʾ�������󳤶���1024����������Ļ�ķֱ���
		SetRect(&rcImage, 0, 0, 1024, cyHeight);		
		InvalidateRect(hwnd, &rcImage, TRUE);
		UpdateWindow(hwnd);
		ReleaseDC(hwnd, hdc);
		//��ʼ��FileDialog
		hInstance = (HINSTANCE)GetWindowLong(hwnd, GWL_ID);
		hwndValue = CreateWindow(TEXT("static"), TEXT("0"), WS_CHILD | WS_VISIBLE | SS_CENTER, 0,0,0,0,
			hwnd, (HMENU)ID_TEXT, hInstance, NULL);
		//ulMeans�㷨��ť 1200, 50, 20 * cxChar, 7 * cyChar / 4
		hwndULMeans = CreateWindow(TEXT("button"), TEXT("��������"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 0, 0, 0, 0,
			hwnd, (HMENU)ID_ULMEANS, hInstance, NULL);
		hwndMAP = CreateWindow(TEXT("button"), TEXT("MAP"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 0, 0, 0, 0,
			hwnd, (HMENU)ID_MAP, hInstance, NULL);
		hwndSLIC = CreateWindow(TEXT("button"), TEXT("SLIC"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 0, 0, 0, 0,
			hwnd, (HMENU)ID_SLIC, hInstance, NULL);		
		hwndMSLIC = CreateWindow(TEXT("button"), TEXT("NLMSLIC"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 0, 0, 0, 0,
			hwnd, (HMENU)ID_NLMSLIC, hInstance, NULL);
		//����һ��������
		hwndScrollImage = CreateWindow(_T("scrollbar"), NULL, WS_CHILD | WS_VISIBLE | WS_TABSTOP | SBS_VERT,
			0, 0, 0, 0, hwnd, (HMENU)1, hInstance, NULL);
		SetScrollRange(hwndScrollImage, SB_CTL, 0 , 99, FALSE);
		SetScrollPos(hwndScrollImage, SB_CTL, 0, FALSE);
		PopFileInitialize(hwnd);		
		return 0;	
	case WM_SIZE:	
		MoveWindow(hwndScrollImage, 1024, 0, 20, cyHeight - 55, TRUE);
		EnableWindow(hwndScrollImage, FALSE);
		break;
		//WM_INITMENUPOPUP ������ֻ�ǳ�ʼ��һ�Σ�����ÿ��Ҫ���»�MENU��ʱ�򶼻��ʼ��
	case WM_INITMENUPOPUP:	
		if(fileType != THREEDR){
			EnableMenuItem((HMENU)wParam, IDM_VIEW_PRE, MF_GRAYED);
			EnableMenuItem((HMENU)wParam, IDM_VIEW_NEXT, MF_GRAYED);		
		}
		break;	
	case WM_VSCROLL:
		i = GetWindowLong((HWND)lParam, GWL_ID);
		switch(LOWORD(wParam)){
		case SB_PAGEDOWN:
			iImage += 6;
		case SB_LINEDOWN:
			iImage = min(iImage + 1, 99);
			break;
		case SB_PAGEUP:
			iImage -= 6;
		case SB_LINEUP:
			iImage = max(0, iImage - 1);
			break;
		case SB_TOP:
			iImage = 0;
			break;
		case SB_BOTTOM:
			iImage = 99;
			break;
		case SB_THUMBPOSITION:
		case SB_THUMBTRACK:
			iImage = HIWORD(wParam);
			break;
		default:
			break;
		}		
		//��֤���ж������ݴ�����
		if(wdImageData){
			baseInfo.width = imgWidth;
			baseInfo.height = imgHeight;
			baseInfo.bits = bits;
			baseInfo.imgIndex = iImage;
			file.baseInfo = baseInfo;
			free(wdImageData);
			//���½������ݵĻ�ȡ������һ��Ҫע������
			file.FileToBmp(&wdImageData, szTempFileName);
			SetScrollPos(hwndScrollImage, SB_CTL, iImage, TRUE);
			InvalidateRect(hwnd, &rcImage, TRUE);
		}
		break;
	case WM_COMMAND:		
		hInstance = (HINSTANCE)GetWindowLong(hwnd, GWL_HINSTANCE);
		switch(LOWORD(wParam)){
		case IDM_FILE_OPEN:
			if(PopFileOpenDlg(hwnd, szFileName, szTitleName)){
				fileType = FileType(szFileName);
				baseInfo.szFileName = szFileName;				
				if(wdImageData) {
					free(wdImageData);
					wdImageData = NULL;
				}
				if(byImageData){
					free(byImageData);
					byImageData = NULL;
				}
				switch(fileType){
				case BMP://ֱ�ӽ��л�ͼ bmp �x�����Ǜ]�І��}��				
					baseInfo.szFileName = szFileName;
					file.baseInfo = baseInfo;					
				/*	if(byImageData){
						free(byImageData);
						byImageData = NULL;
					}*/
					file.BmpFileRead(&byImageData);	
					imgWidth = file.baseInfo.width;
					imgHeight = file.baseInfo.height;
					InvalidateRect(hwnd, &rcImage, TRUE);				
					break;
				case RAW: //�x�ĕr��û���}�����ĕr���І��} �����Խ���д��bmp�ļ�Ȼ�������ʾ					
					if(DialogBox(hInstance, MAKEINTRESOURCE(IDD_DIALOG_IMGATTR), hwnd, ImageAttrDlgProc)){												
						baseInfo.width = imgWidth;
						baseInfo.height = imgHeight;
						baseInfo.bits = bits;
						baseInfo.imgIndex = 0;
						file.baseInfo = baseInfo;
						file.FileToBmp(&wdImageData, szTempFileName);
						InvalidateRect(hwnd, &rcImage, TRUE);
					}
					break;
				case DCM: //��д����û�������							
					SetCursor(LoadCursor(NULL, IDC_WAIT));					
					dicomHandler.DicomRead(szFileName, &wdImageData);				
					SetCursor(LoadCursor(NULL, IDC_ARROW));
					imgWidth = dicomHandler.cols;
					imgHeight = dicomHandler.rows;
					baseInfo.windowCenter = dicomHandler.windowCenter;
					baseInfo.windowWidth = dicomHandler.windowWidth;
					baseInfo.width = imgWidth;
					baseInfo.height = imgHeight;
					baseInfo.bits = dicomHandler.pixDataLen;
					baseInfo.fileType = DCM;
					file.baseInfo = baseInfo;					
					byImageData = file.Nomalization(wdImageData);
					file.WriteToBmpFile(szTempFileName, byImageData);
					byImageData = NULL;					
					InvalidateRect(hwnd, &rcImage, TRUE);
					break;
				case THREEDR://�x�ĕr��û���}�����ĕr���І��}					
					if(DialogBox(hInstance, MAKEINTRESOURCE(IDD_DIALOG_IMGATTR), hwnd, ImageAttrDlgProc)){
						baseInfo.width = imgWidth;
						baseInfo.height = imgHeight;
						baseInfo.bits = bits;
						baseInfo.imgIndex = iImage;
						file.baseInfo = baseInfo;
						file.FileToBmp(&wdImageData, szTempFileName);
						//WriteToBMPFile(hdc, wdImageData, fileType, iMax);
						InvalidateRect(hwnd, &rcImage, TRUE);
					}
					break;
				case OTHERS:	
					MessageBox(hwnd, _T("������ļ���ʽ��"), NULL, MB_ICONERROR);
					break;
				}							
			}				
			DoCaption(hwnd, szTitleName);
			return 0;
		case IDM_FILE_SAVE:
			if(PopFileSaveDlg(hwnd, szFileName, szTitleName)){
				if(CopyFile(szTempFileName, szFileName, TRUE)){
					MessageBox(hwnd, _T("�ļ�����ɹ���"), NULL, MB_ICONINFORMATION);
				}
			}
			return 0;
		case IDM_HELP_IMAGESHOW:
			DialogBox(hInstance, MAKEINTRESOURCE(IDD_DIALOG_ABOUT), hwnd, AboutDlgProc);	

			break;
		case IDM_VIEW_NEXT:
			iImage = min(iImage + 1, 99);
			file.baseInfo.imgIndex = iImage;
			file.baseInfo.width = imgWidth;
			file.baseInfo.height = imgHeight;
			file.baseInfo.bits = bits;
			file.baseInfo.szFileName = szFileName;
			if(wdImageData) free(wdImageData);
			file.FileToBmp(&wdImageData, szTempFileName);
			//WriteToBMPFile(hdc, wdImageData, fileType, iMax);
		    InvalidateRect(hwnd, &rcImage, TRUE);
			break;
		case IDM_VIEW_PRE:
			file.baseInfo.imgIndex = iImage;
			file.baseInfo.width = imgWidth;
			file.baseInfo.height = imgHeight;
			file.baseInfo.bits = bits;
			file.baseInfo.szFileName = szFileName;
			file.baseInfo.imgIndex = iImage;
			if(wdImageData) free(wdImageData);
			file.FileToBmp(&wdImageData, szTempFileName);
			//WriteToBMPFile(hdc, wdImageData, fileType, iMax);
			InvalidateRect(hwnd, &rcImage, TRUE);
			break;
			//���ӵ��㷨�У����㷨���������
		case ID_ULMEANS:	
			SetCursor(LoadCursor(NULL, IDC_WAIT));	
			if((!wdImageData)  && (!byImageData)){
				MessageBox(hwnd, _T("���ȴ�ͼƬ��"), NULL, MB_ICONINFORMATION);
				break;
			}	
			if(byImageData && !wdImageData){
				wdImageData = (WORD *)malloc(imgWidth * imgHeight * sizeof(WORD));
				for(i = 0; i < imgHeight; ++ i)
					for(j = 0; j < imgWidth; ++ j)
						wdImageData[i * imgWidth + j] = byImageData[i * imgWidth + j];
			}
			//start = clock();	
			sigmaN = NSD(wdImageData, imgWidth, imgHeight, 8);
			/*stop = clock();*/
			//TCHAR szDur[10];
			////double dur = (double)(stop - start) / CLOCKS_PER_SEC;
			////wsprintf(szDur, _T("%lf"), dur);
			////OutputDebugString(szDur);
			////break;
			nlmNoise = 18 * sigmaN;			
			//h = 15 * sigmaN;
			//NLMeans(wdImageData, imgWidth, imgHeight, 1.0f / (nlmNoise * nlmNoise), lerpC);
			QNLMeans(wdImageData, imgWidth, imgHeight, 1.0f / (nlmNoise * nlmNoise), lerpC);					
			//NLMeans_cpu(&wdImageData, imgWidth, imgHeight, (1.0f / (nlmNoise * nlmNoise)), lerpC);			
			
			file.baseInfo.width = imgWidth;
			file.baseInfo.height = imgHeight;
			file.baseInfo.bits = bits;
			file.baseInfo.szFileName = szFileName;			 
			for(i = 0; i < imgHeight; ++ i)
				for(j = 0; j < imgWidth; ++ j){
					if(maxPixel < wdImageData[i * imgWidth + j])
						maxPixel = wdImageData[i * imgWidth + j];
				}			
			file.baseInfo.maxPixel = maxPixel;
			byImageData = file.Nomalization(wdImageData);
			file.WriteToBmpFile(szTempFileName, byImageData);	
			SetCursor(LoadCursor(NULL, IDC_ARROW));
			InvalidateRect(hwnd, &rcImage, TRUE);		
			break;
		case ID_MAP:
			if((!wdImageData)  && (!byImageData)){
				MessageBox(hwnd, _T("���ȴ�ͼƬ��"), NULL, MB_ICONINFORMATION);
				break;
			}	
			SetCursor(LoadCursor(NULL, IDC_WAIT));				
			if(byImageData && !wdImageData){
				wdImageData = (WORD *)malloc(imgWidth * imgHeight * sizeof(WORD));
				for(i = 0; i <= imgHeight; ++ i)
					for(j = 0; j < imgWidth; ++ j)
						wdImageData[i * imgWidth + j] = byImageData[i * imgWidth + j];
			}
			MAP(&wdImageData, imgWidth, imgHeight);
			file.baseInfo.width = imgWidth;
			file.baseInfo.height = imgHeight;
			file.baseInfo.bits = bits;
			file.baseInfo.szFileName = szFileName;			 
			for(i = 0; i < imgHeight; ++ i)
				for(j = 0; j < imgWidth; ++ j){
					if(maxPixel < wdImageData[i * imgWidth + j])
						maxPixel = wdImageData[i * imgWidth + j];
				}			
			file.baseInfo.maxPixel = maxPixel;
			byImageData = file.Nomalization(wdImageData);
			file.WriteToBmpFile(szTempFileName, byImageData);	
			SetCursor(LoadCursor(NULL, IDC_ARROW));
			InvalidateRect(hwnd, &rcImage, TRUE);		
			break;
		case ID_SLIC:	
			if((!wdImageData)  && (!byImageData)){
				MessageBox(hwnd, _T("���ȴ�ͼƬ��"), NULL, MB_ICONINFORMATION);
				break;
			}	
			if(byImageData && !wdImageData){
				wdImageData = (WORD *)malloc(imgWidth * imgHeight * sizeof(WORD));
			    for(i = 0; i < imgHeight; ++ i)
					for(j = 0; j < imgWidth; ++ j)
						wdImageData[i * imgWidth + j] = byImageData[i * imgWidth + j];
			}
			SLIC(&wdImageData, imgWidth, imgHeight, expected_sp_number, iterC, weight);
			file.baseInfo.width = imgWidth;
			file.baseInfo.height = imgHeight;
			file.baseInfo.bits = bits;
			file.baseInfo.szFileName = szFileName;			
			for(i = 0; i < imgHeight; ++ i)
				for(j = 0; j < imgWidth; ++ j){
					if(wdImageData[i * imgWidth + j] > maxPixel)
						maxPixel = wdImageData[i * imgWidth + j];
				}
			file.baseInfo.maxPixel = maxPixel;
			byImageData = file.Nomalization(wdImageData);
			file.WriteToBmpFile(szTempFileName, byImageData);						
			InvalidateRect(hwnd, &rcImage, TRUE);		
			break;
			/*if( ! mclInitializeApplication(NULL,0) )
			{
				fprintf(stderr, "Could not initialize the application.n");
				exit(1);
			}*/
			/*if(!libspineInitializeWithHandlers(NULL, 0)){
			fprintf(stderr, "Could not initialize the application.n");
			exit(1);
			}*/
			//libspineInitialize()����ע����libspine.lib��Ҳע����matlab������һЩ���ӿ�
			/*if(!libMyAddInitialize()){
				exit(1);	
			}*/
			//int len = imgWidth * imgHeight;
			//int *segment_label = new int[len];
			//mwArray mat_segment_label(imgHeight, imgWidth, mxDOUBLE_CLASS);
			//mwArray mat_file_name(szFileName);
			//mwArray super_pixels(1,1, mxINT32_CLASS);
			//int count = 500;		
			//super_pixels.SetData(&count, 1);
			////segment_label = mxCreateNumericMatrix(imgWidth, imgHeight, mxDOUBLE_CLASS, mxREAL);
			//slic_greyimage(1, mat_segment_label, mat_file_name, super_pixels);
			//mat_segment_label.GetData(segment_label, len);
			//libspineTerminate();
			//mclTerminateApplication();
				/*MessageBox(hwnd, _T("bingo��"), NULL, MB_ICONINFORMATION);
				libMyAddTerminate();*/
			//break;
		case ID_NLMSLIC:
			if((!wdImageData)  && (!byImageData)){
				MessageBox(hwnd, _T("���ȴ�ͼƬ��"), NULL, MB_ICONINFORMATION);
				break;
			}	
			if(byImageData && !wdImageData){
				wdImageData = (WORD *)malloc(imgWidth * imgHeight * sizeof(WORD));
				for(i = 0; i < imgHeight; ++ i)
					for(j = 0; j < imgWidth; ++ j)
						wdImageData[i * imgWidth + j] = byImageData[i * imgWidth + j];
			}
			sigmaN = NSD(wdImageData, imgWidth, imgHeight, 8);			
			nlmNoise = 18 * sigmaN;		
			NLM_SLIC(&wdImageData, imgWidth, imgHeight, expected_sp_number, iterC, weight, 1.0f / (nlmNoise * nlmNoise), lerpC);
			file.baseInfo.width = imgWidth;
			file.baseInfo.height = imgHeight;
			file.baseInfo.bits = bits;
			file.baseInfo.szFileName = szFileName;			
			for(i = 0; i < imgHeight; ++ i)
				for(j = 0; j < imgWidth; ++ j){
					if(wdImageData[i * imgWidth + j] > maxPixel)
						maxPixel = wdImageData[i * imgWidth + j];
				}
				file.baseInfo.maxPixel = maxPixel;
				byImageData = file.Nomalization(wdImageData);
				file.WriteToBmpFile(szTempFileName, byImageData);						
				InvalidateRect(hwnd, &rcImage, TRUE);	
			break;
		}
		return 0;
		//Ӧ�ý�ͼƬ��ʾ����ʾ������м�λ��	
	
	case WM_PAINT:
		hdc = BeginPaint(hwnd, &ps);
		FillRect(hdc, &rcImage, (HBRUSH)CreateSolidBrush(RGB(0, 0, 0)));				 
		if(wdImageData || byImageData){
			//��ʾ�㷨��ť
			MoveWindow(hwndULMeans, 1200, 50, 20 * cxChar, 7 * cyChar / 4, TRUE);
			MoveWindow(hwndMAP, 1200, 100, 20 * cxChar, 7 * cyChar / 4, TRUE);
			MoveWindow(hwndSLIC, 1200, 150, 20 * cxChar, 7 * cyChar / 4, TRUE);
			MoveWindow(hwndMSLIC, 1200, 200, 20 * cxChar, 7 * cyChar / 4, TRUE);
			//�˴�����ͼ����ʾ
			hInstance = (HINSTANCE)GetWindowLong(hwnd, GWL_HINSTANCE);		
			TCHAR * szTemp = NULL;
			if(wdImageData)
				szTemp = szTempFileName;
			else
				szTemp = szFileName;
			hBitmap = (HBITMAP)LoadImage(hInstance, szTemp, IMAGE_BITMAP, 0, 0, LR_LOADFROMFILE);				
			GetObject(hBitmap, sizeof(BITMAP), &bitmap);										
			hdc = GetDC(hwnd);
			hdcMem = CreateCompatibleDC(hdc);
			SelectObject(hdcMem, hBitmap);
			BitBlt(hdc, 0, 0, bitmap.bmWidth, bitmap.bmHeight, hdcMem, 0, 0, SRCCOPY);			
			DeleteDC(hdcMem);
			DeleteObject(hBitmap);
			ReleaseDC(hwnd,hdc);
		}
		
		if(fileType == THREEDR){			
			EnableWindow(hwndScrollImage, TRUE);
			if(iImage > 0 && iImage < 99){
				EnableMenuItem(hMenu, IDM_VIEW_PRE, MF_ENABLED);
				EnableMenuItem(hMenu, IDM_VIEW_NEXT, MF_ENABLED);
			}else if(iImage == 0){ 
				EnableMenuItem(hMenu, IDM_VIEW_PRE, MF_GRAYED);
				EnableMenuItem(hMenu, IDM_VIEW_NEXT, MF_ENABLED);
			}else{
				EnableMenuItem(hMenu, IDM_VIEW_PRE, MF_ENABLED);
				EnableMenuItem(hMenu, IDM_VIEW_NEXT, MF_GRAYED);
			}
			//��ʾͼƬ���
			SetWindowPos(hwndValue, 0, 500, 5, 20, 20, SWP_SHOWWINDOW);
			//MoveWindow(hwndValue, 500, 5, 20, 20, TRUE);
			wsprintf(szBuffer, TEXT("%i"), (iImage + 1));
			SetWindowText(hwndValue, szBuffer);
		}else{	
			iImage = 0;
			SetScrollPos(hwndScrollImage, SB_CTL, 0, TRUE);
			SetWindowPos(hwndValue, 0, 500, 5, 20, 20, SWP_HIDEWINDOW);				
			EnableWindow(hwndScrollImage, FALSE);
		}
		EndPaint(hwnd, &ps);
		return 0;
	case WM_DESTROY:		
		free(wdImageData);
		_CrtDumpMemoryLeaks();
		PostQuitMessage(0);
		return 0;
	}
	return DefWindowProc(hwnd, message, wParam, lParam);
}
BOOL CALLBACK AboutDlgProc(HWND hwndDlg, UINT message, WPARAM wParam, LPARAM lParam){
	switch(message){
	case WM_INITDIALOG:
		return TRUE;	
	case WM_COMMAND:
		switch(LOWORD(wParam)){
			//ѡ�����ϽǵĲ��ʱ�ᷢ��IDCANCEL��Ϣ
		case IDCANCEL:
		case IDOK:
			EndDialog(hwndDlg, 0);
			return TRUE;
		}
		break;
	}
	return FALSE;
}
BOOL CALLBACK ImageAttrDlgProc(HWND hwndDlg, UINT message, WPARAM wParam, LPARAM lParam){
	TCHAR szWidth[5], szHeight[5];
	TCHAR *szLengths[3]={TEXT("512"), TEXT("1024"), TEXT("2048")};
	static int iBits = IDC_IMG_8;
	int i;
	HWND hComWidth, hComHeight;
	switch(message){
		//��仰����Ҫд
	case WM_INITDIALOG:
		CheckRadioButton(hwndDlg, IDC_IMG_8, IDC_IMG_24, IDC_IMG_16);
		hComWidth = (HWND)GetDlgItem(hwndDlg, IDC_IMGWIDTH);
		hComHeight = (HWND)GetDlgItem(hwndDlg, IDC_IMGHEIGHT);
		SendMessage(hComWidth, LB_RESETCONTENT, 0, 0);
		SendMessage(hComHeight, LB_RESETCONTENT, 0, 0);
		for(i = 0; i < 3; i ++){
			SendMessage(hComWidth, CB_ADDSTRING, i, (LPARAM)szLengths[i]);
			SendMessage(hComHeight, CB_ADDSTRING, i, (LPARAM)szLengths[i]);
		}
		SendMessage(hComWidth, CB_SETCURSEL, 1, 0);
		SendMessage(hComHeight, CB_SETCURSEL, 1, 0);
		return TRUE;		
	case WM_COMMAND:
		switch(LOWORD(wParam)){
		case IDC_IMG_8:
		case IDC_IMG_16:
		case IDC_IMG_24:
			bits  = ( LOWORD(wParam) - 1006) * 8;
			CheckRadioButton(hwndDlg, IDC_IMG_8,IDC_IMG_16, LOWORD(wParam));
			break;
		case IDOK:				
			GetDlgItemText(hwndDlg, IDC_IMGWIDTH, szWidth, 5);
			GetDlgItemText(hwndDlg, IDC_IMGHEIGHT, szHeight, 5);			
			imgWidth = _ttoi(szWidth);
			imgHeight = _ttoi(szHeight);
			EndDialog(hwndDlg, TRUE);
			return TRUE;//��ʱҪ��������
		case IDCANCEL:
			EndDialog(hwndDlg, TRUE);
			return FALSE;
		default:
			break;
		}
		break;
	}
	return FALSE;
}
/*
	���
	ʵ���ļ���ק��ʾ���ܣ��ɿ����ʱ��ʾ�ļ�
	ʵ�ֱ����ļ�����
	ʵ����껬������������
	bug �ļ��ƶ��Ժ��ʱ����������Ӧ����ʾ
	�ᱻ�ŵúô󣡣�����
*/
//File file;		
	//file.WriteToBmpFile(szTempFileName, imgWidth, imgHeight, byImageData);
	//free(byImageData);����Ŀռ��ں���bitmap8���Ѿ��ͷŹ���
	//������д���ض����Ƶ��ļ��У�Ȼ���ٶ���
	/*for(int i = 0; i < imgWidth; i++)
		for(int j = 0; j < imgHeight; j++)
		{			
			double dbColor;
			if(bits == 16){		
				dbColor = (double)wdImageData[i * width + j] / iMax * 255;
			}
			else 
				dbColor = wdImageData[i * width + j];
			COLORREF color = RGB(dbColor,dbColor,dbColor);
			SetPixel(hdc, j, i, color);
		}	*/