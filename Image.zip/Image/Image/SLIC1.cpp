#include<math.h>
typedef unsigned short WORD;
typedef int (R*)[3];
#define inf 65536
void get_segmentseeds(WORD *wdImageData, int width, int height, int segmentseeds[][3], int expected_sp_number, int &superpixel_number_real)
{
	int superpixel_size = (width * height) / expected_sp_number;
	int superpixel_step = floor(sqrt(superpixel_size) + 0.5);
	int width_strips = round(0.5 + width / superpixel_step);
	int height_strips = round(0.5 + height / superpixel_step);
	int width_err = width - superpixel_step * width_strips;
	if(width_err < 0){
		width_strips = width_strips - 1;
		width_err = width - superpixel_step * width_strips;
	}
	int height_err = height - height_strips * superpixel_step;
	if(height_err < 0){
		height_strips -= 1;
		height_err = height - superpixel_step * height_strips;
	}
	int width_errperstrip = width_err / width_strips;
	int height_errperstrip = height_err / height_strips;
	//segmentseeds ����ʢ�ų�ʼ���ӵ㣬Ҫ�з���ֵ
	/*int segmentseeds = new int*[expected_sp_number];
	for(int i = 0; i < expected_sp_number; ++ i){
	segmentseeds[i] = new int[3]();
	}*/
	int width_off = superpixel_step / 2;
	int height_off = superpixel_step / 2;
	int  seed_index = 0;
	for(int j = 1; j < height_strips; ++ j){
		int height_e = (j - 1) * height_errperstrip;
		int seed_j = floor((j - 1) * superpixel_step + height_off + height_e);
		for(int i = 1; i < width_strips; ++ i){
			int width_e = (i - 1) * width_errperstrip;
			int seed_i = floor((i - 1) * superpixel_step + width_off + width_e);
			int seed_intensity = wdImageData[seed_j * width + seed_i];
			segmentseeds[seed_index][0] = seed_i;
			segmentseeds[seed_index][1] = seed_j;
			segmentseeds[seed_index][2] = seed_intensity;
			seed_index ++;
		}
	}	
	superpixel_number_real = seed_index;
}
void get_segment_label(WORD *wdImageData, int width, int height, int expected_sp_number, int *segment_label, int segmentseeds[][3], int superpixel_number_real, int iterC)
{
	int m_weight = 10;
	int error_threshold = round(expected_sp_number * 0.1);
	int superpixel_size = (width * height) / expected_sp_number;
	int superpixel_square = floor((sqrt(superpixel_size) + 0.5) / 2);
	int *pixel_distance = new int[width * height]();
	for(int i = 0; i < width * height; ++ i)
		pixel_distance[i] = inf;
	for(int iter = 0; iter < iterC; ++ i){
		for(int m = 1; m < superpixel_number_real; ++ i){
			int seed_i = segmentseeds[m][0];
			int seed_j = segmentseeds[m][1];
			int seed_intensity = segmentseeds[m][2];
			int i_left = seed_i -superpixel_square * 2;
			int i_right = seed_i + superpixel_square * 2;
			int j_left = seed_j - superpixel_square * 2;
			int j_right = seed_j + superpixel_square * 2;
			i_left = max(i_left, 1);
			i_right = min(i_right, width);
			j_left = max(j_left, 1);
			j_right = min(j_right, height);
			for(int pixel_j = j_left; pixel_j < j_right; ++ pixel_j)
				for(int pixel_i = i_left; pixel_i < i_right; ++ pixel_i){
					int pixel_intensity = wdImageData[pixel_j * width + pixel_i];
					int distance_spatial = sqrt((seed_i - pixel_i) * (seed_i - pixel_i) + (seed_j - pixel_j) * (seed_j - pixel_j));
					int distance_intensity = abs(seed_intensity - pixel_intensity);
					double distance_np = distance_intensity + distance_spatial * m_weight / superpixel_square;
					if(distance_np < pixel_distance[pixel_j * width + pixel_i]){
						pixel_distance[pixel_j * width + pixel_i] = distance_np;
						segment_label[pixel_j * width + pixel_i] = m;
					}
				}
		}			
	}
}