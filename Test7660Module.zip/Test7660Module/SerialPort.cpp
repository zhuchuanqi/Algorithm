//////////////////////////////////////////////////////////////////////////
//	Serial Port
//	Siva Gy
//	2011/12/14
//////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "SerialPort.h"
#include <memory.h>
//////////////////////////////////////////////////////////////////////////
//	Constructor/Destructor
//////////////////////////////////////////////////////////////////////////
CSerialPort::CSerialPort(void)
{
	m_iPortIndex = 1;//Ĭ�϶˿���1
	m_iBaudRate  = CBR_9600;//Ĭ�ϵ�ģ������4880
	m_iParity    = 0; //Ĭ������У�鷽ʽ
	m_iByteSize  = 8;
	m_iStopBits  = ONESTOPBIT;

	memset(&m_olCommEvent,  0, sizeof(OVERLAPPED));
	/* m_olCommEvent�������ź�״̬ */
	m_olCommEvent.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);

	m_uiBytesToBeRead = 1024;//1024*4���ֽ�
	m_uiBufferLenR = 1024;//��ȡ��������СΪ1024���ֽ�
	m_pBufferR = new BYTE[m_uiBufferLenR];
	memset(m_pBufferR, 255, m_uiBufferLenR*sizeof(BYTE));
	memset(&m_olRead,  0, sizeof(OVERLAPPED));
	//��ȡ���ź�״̬�������ȴ���ȡ�¼�
	m_olRead.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	
	/*������ź�״̬*/
	m_uiBufferLenW = 1024;
	m_pBufferW = new BYTE[m_uiBufferLenW];
	memset(m_pBufferW, 255, m_uiBufferLenW*sizeof(BYTE));
	memset(&m_olWrite, 0, sizeof(OVERLAPPED));
	//������ź�״̬�������ȴ��������¼�
	m_olWrite.hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
	
	//�򿪴��ڵķ��ؾ�� m_hComm ��ʼ��ΪINVALID_HANDLE_VALUE����Ч�ľ��ֵ��
	m_hComm			= INVALID_HANDLE_VALUE;
	//�¿����Ľ��̾��
	m_hListenThread = INVALID_HANDLE_VALUE;

	m_bThreadRunning = FALSE;
	/*�β�Ϊconst BYTE* int void * �ĺ���ָ��*/
	m_pfuncDataReadCallback = NULL;
	m_pfuncDataReadUserContext = NULL;
}	

CSerialPort::~CSerialPort(void)
{
	DirectCloseComm();

	if (m_pBufferR)          //��д˼·����д����
	{
		delete[] m_pBufferR;
		m_pBufferR = NULL;
	}
	if (m_pBufferW)
	{
		delete[] m_pBufferW;
		m_pBufferW = NULL;
	}

	if (m_olCommEvent.hEvent)
	{
		CloseHandle(m_olCommEvent.hEvent);
		m_olCommEvent.hEvent = NULL;
	}
	if (m_olRead.hEvent)
	{
		CloseHandle(m_olRead.hEvent);
		m_olRead.hEvent = NULL;
	}
	if (m_olWrite.hEvent)
	{
		CloseHandle(m_olWrite.hEvent);
		m_olWrite.hEvent = NULL;
	}
}

void CSerialPort::OnDataRead(const BYTE* pBuffer, const int iLen)
{
	if (m_pfuncDataReadCallback)
	{
		m_pfuncDataReadCallback(pBuffer, iLen, m_pfuncDataReadUserContext);
	}
}
/*
	�Ķ�wchar_t
*/
void CSerialPort::OnError(const char* wszError)
{
	OutputDebugString(wszError);
}
/*
	�����ȡ�ĳ�����Ϣ
*/
void CSerialPort::DebugPort1(int iLen)
{
	CString strTemp;
#ifdef _DEBUG
	strTemp.Format(_T("\nSP_IN>>Length = %d. "), iLen);	
#else
	strTemp.Format(_T("SP_IN>>Length = %d. "), iLen);	
#endif // _DEBUG
	OutputDebugString(strTemp);
}
/*
   ���������Ϣ+��ȡ��������Ϣ
*/
void CSerialPort::DebugPort2(const BYTE* pucBuffer, const int iLen)
{
	CString strText, strTemp;
#ifdef _DEBUG
	strText.Format(_T("\nSP_IN>>Read Out(%d) ="), iLen);
#else
	strText.Format(_T("SP_IN>>Read Out(%d) ="), iLen);
#endif // _DEBUG
	for (register int i=0; i<iLen; i++)
	{
		/*%02X ��ʮ�����Ʊ�ʾ�����������λǰ����0���룬����������*/
		strTemp.Format(_T(" %02X"), *(pucBuffer+i));
		strText += strTemp;
	}
	strText += _T(". ");
	OutputDebugString(strText);
}

void CSerialPort::DebugPort3(int iLen)
{
	CString strTemp;
	strTemp.Format(_T("SP_OUT<<Length = %d. "), iLen);	
	OutputDebugString(strTemp);
}

void CSerialPort::DebugPort4(const BYTE* pucBuffer, const int iLen)
{
	CString strText, strTemp;

	strText.Format(_T("SP_OUT<<Write to(%d) ="), iLen);
	for (register int i=0; i<iLen; i++)
	{
		strTemp.Format(_T(" %02X"), *(pucBuffer+i));
		strText += strTemp;
	}
	strText += _T(". ");
#ifdef _DEBUG
	strText += _T("\n");
#endif // _DEBUG

	OutputDebugString(strText);
}
//////////////////////////////////////////////////////////////////////////
//	Added by Siva
void CSerialPort::SetPortIndex(const int iPortIndex /* = 1 */)
{
	m_iPortIndex = iPortIndex;
}
/*ΪʲôҪ��˿ںţ�*/
int CSerialPort::GetPortIndex()
{
	return m_iPortIndex;
}

void CSerialPort::SetBaudRate(const int iBaudRate)
{
	switch (iBaudRate)
	{
	case 110:
		{
			m_iBaudRate = CBR_110;
			break;
		}
	case 300:
		{
			m_iBaudRate = CBR_300;
			break;
		}
	case 600:
		{
			m_iBaudRate = CBR_600;
			break;
		}
	case 1200:
		{
			m_iBaudRate = CBR_1200;
			break;
		}
	case 2400:
		{
			m_iBaudRate = CBR_2400;
			break;
		}
	case 4800:
		{
			m_iBaudRate = CBR_4800;
			break;
		}
	case 9600:
		{
			m_iBaudRate = CBR_9600;
			break;
		}
	case 14400:
		{
			m_iBaudRate = CBR_14400;
			break;
		}
	case 19200:
		{
			m_iBaudRate = CBR_19200;
			break;
		}
	case 38400:
		{
			m_iBaudRate = CBR_38400;
			break;
		}
	case 56000:
		{
			m_iBaudRate = CBR_56000;
			break;
		}
	case 57600:
		{
			m_iBaudRate = CBR_57600;
			break;
		}
	case 115200:
		{
			m_iBaudRate = CBR_115200;
			break;
		}
	case 128000:
		{
			m_iBaudRate = CBR_128000;
			break;
		}
	case 256000:
		{
			m_iBaudRate = CBR_256000;
			break;
		}
	default:
		{
			m_iBaudRate = CBR_4800;
			break;
		}
	}
}

int CSerialPort::GetBaudRate()
{
	switch (m_iBaudRate)
	{
	case CBR_110:
		{
			return 110;
		}
	case CBR_300:
		{
			return 300;
		}
	case CBR_600:
		{
			return 600;
		}
	case CBR_1200:
		{
			return 1200;
		}
	case CBR_2400:
		{
			return 2400;
		}
	case CBR_4800:
		{
			return 4800;
		}
	case CBR_9600:
		{
			return 9600;
		}
	case CBR_14400:
		{
			return 14400;
		}
	case CBR_19200:
		{
			return 19200;
		}
	case CBR_38400:
		{
			return 38400;
		}
	case CBR_56000:
		{
			return 56000;
		}
	case CBR_57600:
		{
			return 57600;
		}
	case CBR_115200:
		{
			return 115200;
		}
	case CBR_128000:
		{
			return 128000;
		}
	case CBR_256000:
		{
			return 256000;
		}
	default:
		{
			return 19200;
		}
	}
}
/*
    #define NOPARITY            0��żУ��
	#define ODDPARITY           1����У��
	#define EVENPARITY          2����У��
*/
void CSerialPort::SetParity(const int iParity /* = 0 */)
{
	m_iParity = iParity;
}

int CSerialPort::GetParity()
{
	return m_iParity;
}
/*
	ÿ���ֽڵ�λ��
*/
void CSerialPort::SetByteSize(const int iByteSize /* = 8 */)
{
	m_iByteSize = iByteSize;
}

int CSerialPort::GetByteSize()
{
	return m_iByteSize;
}
/*
	����ֹͣλ����
*/
void CSerialPort::SetStopBits(const int iStopBits /* = 1 */)
{
	switch (iStopBits)
	{
	case 1:
		{	
			m_iStopBits = ONESTOPBIT;
			break;
		}
	case 2:
		{
			m_iStopBits = TWOSTOPBITS;
			break;
		}
	default:
		{
			m_iStopBits = ONESTOPBIT;
			break;
		}
	}
}

int CSerialPort::GetStopBits()
{
	switch (m_iStopBits)
	{
	case ONESTOPBIT:
		{
			return 1;
		}
	case TWOSTOPBITS:
		{
			return 2;
		}
	default:
		{
			return 1;
		}
	}
}

//////////////////////////////////////////////////////////////////////////
//	Added by Siva
void CSerialPort::SetBufferLenR(const unsigned int uiBufferLenR)
{
	if (uiBufferLenR > m_uiBufferLenR)
	{
		delete[] m_pBufferR;
		m_pBufferR = new BYTE[uiBufferLenR];
		memset(m_pBufferR, 255, uiBufferLenR*sizeof(BYTE));
		m_uiBufferLenR = uiBufferLenR;
	}
	m_uiBytesToBeRead = uiBufferLenR;
}

unsigned int CSerialPort::GetBufferLenR()
{
	return m_uiBufferLenR;
}

void CSerialPort::SetBufferLenW(const unsigned int uiBufferLenW)
{
	if (uiBufferLenW > m_uiBufferLenW)
	{
		delete[] m_pBufferW;
		m_pBufferW = new BYTE[uiBufferLenW];
		memset(m_pBufferW, 255, uiBufferLenW*sizeof(BYTE));
		m_uiBufferLenW = uiBufferLenW;
	}	
}

unsigned int CSerialPort::GetBufferLenW()
{
	return m_uiBufferLenW;
}

BYTE* CSerialPort::GetBufferR()
{
	return m_pBufferR;
}

BYTE* CSerialPort::GetBufferW()
{
	return m_pBufferW;
}
//////////////////////////////////////////////////////////////////////////
//	Added by Chuanqi
HANDLE CSerialPort::GetHComm()
{
	return m_hComm;
}
//////////////////////////////////////////////////////////////////////////
//	Added by Siva
//////////////////////////////////////////////////////////////////////////
/*
	���򿪴���(��CreateFile����ʵ�ִ�)ʱ���������������
*/
DWORD CSerialPort::ListenThreadProc(LPVOID pParam)   //���ԶԷ�����Ϣ���ж�ȡ
{
	//AfxMessageBox("�߳̿�����");
	//�����ݵ����ͽ���ǿ������ת���õ�CSerialPort����ָ��
	CSerialPort* pSerialPort = reinterpret_cast<CSerialPort*>(pParam);
	DWORD dwEventMask, dwResult, dwErrors, dwBytesRead;
	COMSTAT statComm;
	BOOL bResult;
	DWORD dwBufferLenR = pSerialPort->GetBufferLenR();
	BYTE* pBufferR = pSerialPort->GetBufferR();
	DWORD dwLoopInterval = 100;
	DWORD dwReadInterval = 100;
	//һ���Ƕ��ڴ��ڵļ����¼���һ���Ƕ��ڶ�ȡ�ļ����¼�
	ResetEvent(pSerialPort->m_olCommEvent.hEvent);
	ResetEvent(pSerialPort->m_olRead.hEvent);

	memset(pBufferR, 255, dwBufferLenR);
	//��ʾ�ĸ��̣߳�
	while(pSerialPort->m_bThreadRunning)
	{
		//�������ļ��ľ�����ȴ��첽�¼��ķ���
		WaitCommEvent(pSerialPort->m_hComm, &dwEventMask, &pSerialPort->m_olWrite);
		//�ȴ��¼��������ߵȴ���ʱ�䳬�����޶�ֵdwLoopInterval����WaitForSingleObject��������
		dwResult = WaitForSingleObject(pSerialPort->m_olWrite.hEvent, dwLoopInterval);
		
		//���û���źŵĻ�������һֱѭ����ֱ�����ź�Ϊֹ
		if (WAIT_OBJECT_0 != dwResult	||  //WAIT_OBJECT_0��ʾ���źţ�WAIT_TIMEOUT ��ʾ�ȴ�һ��ʱ�䣬����һֱû�ź�
			EV_RXCHAR	  != dwEventMask)
		{
			continue;
		}
		
		memset(&statComm, 0, sizeof(COMSTAT));//��������ɹ��Ļ���
		ClearCommError(pSerialPort->m_hComm, &dwErrors, &statComm);
		//���Ķ�
		if (statComm.cbInQue <= 0/*pSerialPort->m_uiBytesToBeRead*/)
		{
			//AfxMessageBox("cbInQue<0");
			continue;
		}	
				
		//pSerialPort->DebugPort1(statComm.cbInQue);
		bResult = ReadFile(pSerialPort->m_hComm, 
						   pBufferR, 
						   pSerialPort->m_uiBytesToBeRead, 
						   &dwBytesRead, 
						   &pSerialPort->m_olRead);
		//pSerialPort->DebugPort2(pBufferR, dwBytesRead);
		
		//�����豸�����������������
		//CString iStr;
		//iStr.Format("��ȡ�����ֽ��� %i",dwBytesRead);
		//AfxMessageBox(iStr);		
		//PurgeComm(pSerialPort->m_hComm, PURGE_RXCLEAR);
		if (bResult)
		{
			//AfxMessageBox("��ȡ�¼�������");
			pSerialPort->OnDataRead(pBufferR, dwBytesRead);						
		}
		else
		{
			//AfxMessageBox("bResultΪ0");	
			//CString errorStr;
			//errorStr.Format("%i",GetLastError());
			//AfxMessageBox(errorStr);
			if (ERROR_IO_PENDING == GetLastError())
			{	
				dwResult = WaitForSingleObject(pSerialPort->m_olRead.hEvent, dwReadInterval);
				if (WAIT_OBJECT_0 == dwResult)
				{
					bResult = GetOverlappedResult(pSerialPort->m_hComm, &pSerialPort->m_olRead, &dwBytesRead, TRUE);
					if (bResult)
					{
					//	AfxMessageBox("��ȡ�¼�������");
						pSerialPort->OnDataRead(pBufferR, dwBytesRead);
					}
				}
			}
		//	AfxMessageBox("dwResult ���� Error_IO_PENDING");
		}
		//pSerialPort->m_bThreadRunning=false;
	}
	/*------
	while(pSerialPort->m_bThreadRunning){              //-------------------------
		Sleep(3000);
		pBufferR[0]=87;
		dwBytesRead=9;
		pSerialPort->OnDataRead(pBufferR, dwBytesRead);//----------------------��Ҫ�h��
	}												   //---------------------------
	----*/    
	pSerialPort->m_hListenThread = INVALID_HANDLE_VALUE;
	return 0;
}



//////////////////////////////////////////////////////////////////////////
//	Added by Siva
//////////////////////////////////////////////////////////////////////////
BOOL CSerialPort::OpenComm()
{
	CString strPortIndex, strMsg;
	DWORD	dwError;
	DCB		dcbComm;

	strPortIndex.Format(_T("COM%d"), m_iPortIndex);

	CloseComm();
	m_hComm = CreateFile(strPortIndex,                
						 GENERIC_READ|GENERIC_WRITE, 
						 0, 
						 NULL, 
						 OPEN_EXISTING, 
						 FILE_ATTRIBUTE_NORMAL|FILE_FLAG_OVERLAPPED,
						 NULL);
	if (INVALID_HANDLE_VALUE == m_hComm)
	{
		dwError = GetLastError();
		strMsg.Format(_T("Open %s failed!\nCode: %d"), strPortIndex, dwError);
		OnError(strMsg);
		return FALSE;
	}

	GetCommState(m_hComm, &dcbComm);
	dcbComm.BaudRate = m_iBaudRate;
	dcbComm.fParity  = m_iParity;
	dcbComm.Parity   = m_iParity % 2;
	dcbComm.fBinary  = TRUE;
	dcbComm.ByteSize = (BYTE)m_iByteSize;
	dcbComm.StopBits = (BYTE)m_iStopBits;
	COMMTIMEOUTS timeOuts;
	timeOuts.ReadIntervalTimeout=100;
	timeOuts.ReadTotalTimeoutMultiplier=0;
	timeOuts.ReadTotalTimeoutConstant=100;	//��ȡһ�β�������������أ������ܶ�ȡ���Ƿ���Ҫ����ַ�
	
	timeOuts.WriteTotalTimeoutMultiplier=500;
	timeOuts.WriteTotalTimeoutConstant=100;
	SetCommTimeouts(m_hComm,&timeOuts);

	SetCommState(m_hComm, &dcbComm);

	

	SetupComm(m_hComm, m_uiBufferLenR, m_uiBufferLenW);

	PurgeComm(m_hComm, PURGE_TXCLEAR|PURGE_RXCLEAR);

	SetCommMask(m_hComm, EV_RXCHAR);    
	m_bThreadRunning = TRUE;

	//�򿪴��ڵ�ͬʱ�¿�����һ���̣߳���������ڲ���cSerialPort����ָ�봫�ݸ���������
	m_hListenThread = CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)CSerialPort::ListenThreadProc, this, 0, NULL);
	if (INVALID_HANDLE_VALUE == m_hListenThread)
	{
		return FALSE;
	}
	
	return TRUE;
}
//ͨ�����ַ�ʽ���Ե�������
BOOL CSerialPort::SendBuffer(const void* pBuffer, const unsigned int uiLen)
{
	if (NULL == pBuffer	||
		uiLen < 1	)
		
	{		
		return FALSE;
	}
	if(INVALID_HANDLE_VALUE == m_hComm){
		AfxMessageBox("����û�д򿪣�");
		return FALSE;
	}

	SetBufferLenW(uiLen);
	/*����  dest, src, length*/
	memcpy(m_pBufferW, pBuffer, uiLen);
	
	ResetEvent(m_olWrite.hEvent);
	
	DWORD dwResult, dwBytesWritten;
	PurgeComm(m_hComm, PURGE_TXCLEAR);
	//ͨ��WriteFile��m_olWrite�ṹ
	dwResult = WriteFile(m_hComm, m_pBufferW, uiLen, &dwBytesWritten, &m_olWrite);
	if (!dwResult)
	{
		dwResult = GetLastError();
		if (ERROR_IO_PENDING != dwResult)
		{
			CString	strMsg;
			strMsg.Format(_T("\n>>>Write failed! Code: %d<<<\n"), dwResult);
			/**/
			OnError(strMsg);
			return FALSE;
		}
	}    
	return TRUE;
}

void CSerialPort::StopThread(BOOL flag)
{
	m_bThreadRunning=flag;
}
void CSerialPort::RegDataReadCallback(LPSPDATAREADCALLBACK pfuncDataReadCallback, void* pUserContext)
{
	m_pfuncDataReadCallback = pfuncDataReadCallback;
	
	m_pfuncDataReadUserContext = pUserContext;
}
BOOL CSerialPort::CloseComm()
{
	if (INVALID_HANDLE_VALUE == m_hComm)
	{
		return TRUE;
	}

	m_bThreadRunning = FALSE;

	WaitForSingleObject(m_hListenThread, INFINITE);
	CloseHandle(m_hListenThread);

	CloseHandle(m_hComm);
	m_hComm = INVALID_HANDLE_VALUE;

	return TRUE;
}

void CSerialPort::DirectCloseComm()
{
	if (m_bThreadRunning)
	{
		m_bThreadRunning = FALSE;
	}

	if (INVALID_HANDLE_VALUE != m_hListenThread)
	{
		CloseHandle(m_hListenThread);
		m_hListenThread = INVALID_HANDLE_VALUE;
	}

	if (INVALID_HANDLE_VALUE != m_hComm)
	{
		CloseHandle(m_hComm);
		m_hComm = INVALID_HANDLE_VALUE;
	}
}
