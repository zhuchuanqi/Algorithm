// Test7660ModuleDlg.h : header file
//
// // // // // // // // // // // // // // // // // // // // // // // // // // // // 
// Chuanqi   
// 2015/7/28
// // // // // // // // // // // // // // // // // // // // // // // // // // // // 
#include "SerialPort.h"
#include "TimeSelDlg.h"
#if !defined(AFX_TEST7660MODULEDLG_H__BF3A0A78_A014_4AE6_8AB2_3E78F032548F__INCLUDED_)
#define AFX_TEST7660MODULEDLG_H__BF3A0A78_A014_4AE6_8AB2_3E78F032548F__INCLUDED_
#define MAXBYTESIZE 1024
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
void LaserThreadFunc();
BOOL SendData(CString daDataStr,int iIndex);
//typedef enum CINDEX{ONE,TWO,THREE,FOUR};
//CINDEX cEIndex;
//typedef void (*LPEXTRADATACALLBACK)(const BYTE* pBuffer, int iBufferLen, void* pUserContext);
/////////////////////////////////////////////////////////////////////////////
// CTest7660ModuleDlg dialog
class CTest7660ModuleDlg : public CDialog
{
public:
	friend BOOL SendData(CString daDataStr,int iIndex,CTest7660ModuleDlg &cTest7660ModuleDlg);
	
private:
	HANDLE hThread;
	DWORD ThreadID;
private:
	bool SelChangeComboC(CString  cStr,int cIndex);
// Construction
public:
	CTest7660ModuleDlg(CWnd* pParent = NULL);	// standard constructor
public:
	void StartTest(int hours);	
	void CloseLaser();
private:
	int m_iHours;
	int m_iMinutes;
	int m_iSeconds;	
private:
	bool m_bBegin;
public:
	void SetHours(int iHours);
	void SetMinutes(int iMinutes);
	void SetSeconds(int iSeconds);
	int GetHours();
	int GetMinutes();
	int GetSeconds();
public:
	/*�ȶ��庯��Ȼ��*/
	//void ExtraDataFromBufferCallBack(const BYTE* pBuffer, int iBufferLen, void* pUserContext);
//private:
//	LPEXTRADATACALLBACK m_pfuncExtraDataCallback;
private:
	BOOL IsDataTypeInput(const CString &strInput,int length);
	void ResetComboBox(int iIndex);
// Dialog Data
	//{{AFX_DATA(CTest7660ModuleDlg)
	enum { IDD = IDD_TEST7660MODULE_DIALOG };
	CComboBox	m_cbC4;
	CComboBox	m_cbC3;
	CComboBox	m_cbC2;
	CComboBox	m_cbC1;
	CComboBox	m_cbPCBR;
	CComboBox	m_cbSP;
	CComboBox	m_cbSN;
	CComboBox	m_cbBr;
	int		m_Radio_Type;
	int		m_Radio_G1;
	int		m_Radio_S;
	int		m_Radio_Sp;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTest7660ModuleDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CTest7660ModuleDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnBtnOpenPC();
	afx_msg void OnButtonSet7660();
	afx_msg void OnBtnClt();
	afx_msg void OnRadioG1();
	afx_msg void OnRadioG10();
	afx_msg void OnRadioG100();
	afx_msg void OnRadioT();
	afx_msg void OnRadioTa();
	afx_msg void OnRadioTb();
	afx_msg void OnRadioS();
	afx_msg void OnRadioTen();
	afx_msg void OnRadioFive();
	afx_msg void OnRadioNfive();
	afx_msg void OnRadioSp();
	afx_msg void OnRadioDp();
	afx_msg void OnSelchangeComboC1();
	afx_msg void OnSelchangeComboC2();
	afx_msg void OnSelchangeComboC3();
	afx_msg void OnSelchangeComboC4();
	afx_msg void OnBTNDurTest();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnEditchangeComboC1();
	afx_msg void OnEditchangeComboC2();
	afx_msg void OnEditchangeComboC3();
	afx_msg void OnEditchangeComboC4();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TEST7660MODULEDLG_H__BF3A0A78_A014_4AE6_8AB2_3E78F032548F__INCLUDED_)
