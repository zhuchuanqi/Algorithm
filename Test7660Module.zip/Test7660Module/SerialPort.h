//////////////////////////////////////////////////////////////////////////
//	Serial Port
//	Siva Gy
//	2011/12/14
//////////////////////////////////////////////////////////////////////////
#pragma once


typedef	void (CALLBACK *LPSPDATAREADCALLBACK)(const BYTE* pBuffer, int iBufferLen, void* pUserContext);

class CSerialPort
{
//////////////////////////////////////////////////////////////////////////
//	Constructor/Destructor/
//////////////////////////////////////////////////////////////////////////
public:
	CSerialPort(void);
	~CSerialPort(void);

//////////////////////////////////////////////////////////////////////////
//	Attributes
//////////////////////////////////////////////////////////////////////////
private:
	int			m_iPortIndex;
	int			m_iBaudRate;
	int			m_iParity;//    У��λ
	int			m_iByteSize;// 
	int			m_iStopBits;//  ֹͣλ

	OVERLAPPED	m_olCommEvent;   

	unsigned int	m_uiBytesToBeRead;
	unsigned int	m_uiBufferLenR;
	BYTE*			m_pBufferR;
	OVERLAPPED		m_olRead;  
	
	unsigned int	m_uiBufferLenW;
	BYTE*			m_pBufferW;
	OVERLAPPED		m_olWrite;

	HANDLE		m_hComm;
	HANDLE		m_hListenThread;//��������
	BOOL		m_bThreadRunning;
	LPSPDATAREADCALLBACK	m_pfuncDataReadCallback;
	void*					m_pfuncDataReadUserContext;

//	CCriticalSection		m_csLock;

public:


//////////////////////////////////////////////////////////////////////////
//	Methods
//////////////////////////////////////////////////////////////////////////
public:
	void StopThread(BOOL flag);
private:
	void	OnDataRead(const BYTE* pBuffer, const int iLen);
	void	OnError(const char* wszError);
	//ʹ��static���Σ�û�н���ָ�룬������Ϊ�̺߳���ʹ��
	static DWORD ListenThreadProc(LPVOID pParam);

	void	DebugPort1(int iLen);
	void	DebugPort2(const BYTE* pucBuffer, const int iLen);
	void	DebugPort3(int iLen);
	void	DebugPort4(const BYTE* pucBuffer, const int iLen);
public:  
	HANDLE  GetHComm();
public:
	void	SetPortIndex(const int iPortIndex = 1);
	int		GetPortIndex();
	void	SetBaudRate(const int iBaudRate);
	int		GetBaudRate();
	void	SetParity(const int iParity = 0);
	int		GetParity();
	void	SetByteSize(const int iByteSize = 8);
	int		GetByteSize();
	void	SetStopBits(const int iStopBits = 1);
	int		GetStopBits();

	void			SetBufferLenR(const unsigned int uiBufferLenR);
	unsigned int	GetBufferLenR();
	void			SetBufferLenW(const unsigned int uiBufferLenW);
	unsigned int	GetBufferLenW();

	BYTE*	GetBufferR();
	BYTE*	GetBufferW();
	/*callback */
	void	RegDataReadCallback(LPSPDATAREADCALLBACK pfuncDataReadCallback, void* pUserContext);
			
	BOOL	OpenComm();
	BOOL	CloseComm();
	void	DirectCloseComm();	
	BOOL	SendBuffer(const void* pBuffer, const unsigned int iLen);
};
