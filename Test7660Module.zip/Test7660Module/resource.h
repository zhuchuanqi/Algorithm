//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Test7660Module.rc
//
#define IDTIMER                         1
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_TEST7660MODULE_DIALOG       102
#define IDR_MAINFRAME                   128
#define IDD_DIALOG1                     139
#define IDC_COMBO_7660BR                1000
#define IDC_COMBO_SP                    1001
#define IDC_COMBO_7660SN                1002
#define IDC_COMBO_PCBR                  1003
#define IDC_BTN_OPENPC                  1004
#define IDC_STATIC_GROUPBOX             1012
#define IDC_RADIO6                      1013
#define IDC_RADIO_T                     1013
#define IDC_RADIO7                      1014
#define IDC_RADIO_TA                    1014
#define IDC_RADIO8                      1015
#define IDC_RADIO_TB                    1015
#define IDC_RADIO_S                     1016
#define IDC_RADIO_TEN                   1017
#define IDC_RADIO_FIVE                  1018
#define IDC_RADIO_NFIVE                 1019
#define IDC_COMBO_C1                    1020
#define IDC_COMBO_C2                    1021
#define IDC_COMBO_C3                    1022
#define IDC_COMBO_C4                    1023
#define IDC_EDIT_T1                     1024
#define IDC_EDIT_T2                     1025
#define IDC_EDIT_T3                     1026
#define IDC_EDIT_T4                     1027
#define IDC_RADIO_SP                    1028
#define IDC_RADIO_DP                    1029
#define IDC_RADIO_G1                    1030
#define IDC_RADIO_G10                   1031
#define IDC_RADIO_G100                  1032
#define IDC_BUTTON_SET7660              1035
#define IDC_BTN_CLT                     1036
#define IDC_BTN_Dur_Test                1037
#define IDC_COMBO_TS                    1038
#define IDC_BTN_SURE                    1039
#define IDC_COMBO2                      1043

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        141
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1044
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
