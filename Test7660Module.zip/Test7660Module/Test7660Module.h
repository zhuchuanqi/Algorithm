// Test7660Module.h : main header file for the TEST7660MODULE application
//

#if !defined(AFX_TEST7660MODULE_H__3E677C0C_F333_4C33_A4CC_29A175A42613__INCLUDED_)
#define AFX_TEST7660MODULE_H__3E677C0C_F333_4C33_A4CC_29A175A42613__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CTest7660ModuleApp:
// See Test7660Module.cpp for the implementation of this class
//

class CTest7660ModuleApp : public CWinApp
{
public:
	CTest7660ModuleApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTest7660ModuleApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CTest7660ModuleApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TEST7660MODULE_H__3E677C0C_F333_4C33_A4CC_29A175A42613__INCLUDED_)
