// // // // // // // // // // // // // // // // // // // // // // // // // // // // 
// Chuanqi   
// 2015/7/28
// // // // // // // // // // // // // // // // // // // // // // // // // // // // 

#include "stdafx.h"
#include "Test7660Module.h"
#include "Test7660ModuleDlg.h"
#ifdef _DEBUG
#define new DEBUG_NEW
const int MaxMS=59;
const int MaxStrLength=10;
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
volatile BOOL m_bRun;

//ʹ��ȫ�ֱ���ʵ�ֶ�����ͨ��
CSerialPort cSerialPort;
/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About
int gainStr;
class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}
//�����Ϣӳ����ΪCAboutDlg�����
BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTest7660ModuleDlg dialog

CTest7660ModuleDlg::CTest7660ModuleDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTest7660ModuleDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTest7660ModuleDlg)
	m_Radio_Type = -1;
	m_Radio_G1 = -1;
	m_Radio_S = -1;
	m_Radio_Sp = -1;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);

}

void CTest7660ModuleDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTest7660ModuleDlg)
	DDX_Control(pDX, IDC_COMBO_C4, m_cbC4);
	DDX_Control(pDX, IDC_COMBO_C3, m_cbC3);
	DDX_Control(pDX, IDC_COMBO_C2, m_cbC2);
	DDX_Control(pDX, IDC_COMBO_C1, m_cbC1);
	DDX_Control(pDX, IDC_COMBO_PCBR, m_cbPCBR);
	DDX_Control(pDX, IDC_COMBO_SP, m_cbSP);
	DDX_Control(pDX, IDC_COMBO_7660SN, m_cbSN);
	DDX_Control(pDX, IDC_COMBO_7660BR, m_cbBr);
	DDX_Radio(pDX, IDC_RADIO_T, m_Radio_Type);
	DDX_Radio(pDX, IDC_RADIO_G1, m_Radio_G1);
	DDX_Radio(pDX, IDC_RADIO_S, m_Radio_S);
	DDX_Radio(pDX, IDC_RADIO_SP, m_Radio_Sp);
	//}}AFX_DATA_MAP
}
//�����Ϣӳ������ΪCTest7600ModuleDlg�����
BEGIN_MESSAGE_MAP(CTest7660ModuleDlg, CDialog)
	//{{AFX_MSG_MAP(CTest7660ModuleDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BTN_OPENPC, OnBtnOpenPC)
	ON_BN_CLICKED(IDC_BUTTON_SET7660, OnButtonSet7660)
	ON_BN_CLICKED(IDC_BTN_CLT, OnBtnClt)
	ON_BN_CLICKED(IDC_RADIO_G1, OnRadioG1)
	ON_BN_CLICKED(IDC_RADIO_G10, OnRadioG10)
	ON_BN_CLICKED(IDC_RADIO_G100, OnRadioG100)
	ON_BN_CLICKED(IDC_RADIO_T, OnRadioT)
	ON_BN_CLICKED(IDC_RADIO_TA, OnRadioTa)
	ON_BN_CLICKED(IDC_RADIO_TB, OnRadioTb)
	ON_BN_CLICKED(IDC_RADIO_S, OnRadioS)
	ON_BN_CLICKED(IDC_RADIO_TEN, OnRadioTen)
	ON_BN_CLICKED(IDC_RADIO_FIVE, OnRadioFive)
	ON_BN_CLICKED(IDC_RADIO_NFIVE, OnRadioNfive)
	ON_BN_CLICKED(IDC_RADIO_SP, OnRadioSp)
	ON_BN_CLICKED(IDC_RADIO_DP, OnRadioDp)
	ON_CBN_SELCHANGE(IDC_COMBO_C1, OnSelchangeComboC1)
	ON_CBN_SELCHANGE(IDC_COMBO_C2, OnSelchangeComboC2)
	ON_CBN_SELCHANGE(IDC_COMBO_C3, OnSelchangeComboC3)
	ON_CBN_SELCHANGE(IDC_COMBO_C4, OnSelchangeComboC4)
	ON_BN_CLICKED(IDC_BTN_Dur_Test, OnBTNDurTest)
	ON_WM_TIMER()
	ON_CBN_EDITCHANGE(IDC_COMBO_C1, OnEditchangeComboC1)
	ON_CBN_EDITCHANGE(IDC_COMBO_C2, OnEditchangeComboC2)
	ON_CBN_EDITCHANGE(IDC_COMBO_C3, OnEditchangeComboC3)
	ON_CBN_EDITCHANGE(IDC_COMBO_C4, OnEditchangeComboC4)	
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTest7660ModuleDlg message handlers
//��ʼ���ؼ�
BOOL CTest7660ModuleDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
    
	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);
	
	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon	
	// TODO: Add extra initialization here
	

	//m_cbBr ������
	m_cbBr.SetCurSel(1);

	//m_cbSP ���ں�
    m_cbSP.SetCurSel(0);	
	
	//m_cbSN վ��
	CString snStr;
	unsigned int sn=100;//վ��
	for(unsigned int i=0;i<=sn;i++){
		snStr.Format("%u",i);
		m_cbSN.InsertString(i,snStr);
	}
	m_cbSN.SetCurSel(0);
    
	//m_cbPCBR pc������
	m_cbPCBR.SetCurSel(1);

	//Ĭ���ͺ�(��radio button�����仯ʱ�����ҲҪ����һ���)
	m_Radio_Type=0;
	//Ĭ�ϵ�ѹ��10v��
	m_Radio_S=1;	
    //Ĭ�ϵ���
	m_Radio_Sp=0;
	//Ĭ������
	m_Radio_G1=0;
	UpdateData(false);
    
	
	//ģ�������ѹcomboBox��ʼ��
    int values[12]={0,204,409,819,1229,1638,2048,2457,2868,3276,3687,4095}; 
	for(int i=0;i<12;i++){		
		CString iStr;
		iStr.Format("%i",values[i]);
		m_cbC1.InsertString(i,iStr);
		m_cbC2.InsertString(i,iStr);
		m_cbC3.InsertString(i,iStr);
		m_cbC4.InsertString(i,iStr);
	}
	//��ʼ��ʱ��
	m_iHours=0;
	m_iMinutes=0;
	m_iSeconds=0;
	//CheckRadioButton(IDC_RADIO_G1,IDC_RADIO_G100,IDC_RADIO_G1);
	//m_Radio_Type=1;
	m_bRun=TRUE;
	m_bBegin=true;
	
	//cEIndex=ONE;//��ʼ������һ

	return TRUE;  // return TRUE  unless you set the focus to a control

}
void CALLBACK ExtraDataFromBufferCallBack(const BYTE* pBuffer, int iBufferLen, void* pUserContext)
{	
	//���xȡ������Ϣ�M���Д࣬�����ģ�Mݔ���ķ���ֵ��Ϣ�t�����@ʾ��TextBox��
	//AfxMessageBox("�ص�ExtraDataFromBufferCallBack��");
	if(10==iBufferLen){
		if(58==pBuffer[0] && 48==pBuffer[1] && 48==pBuffer[2] && 87==pBuffer[3] && 56==pBuffer[4]){
			CString iRebackStr;
			int iReback=pBuffer[6] * 256 + pBuffer[7];
			iRebackStr.Format("%i",iReback);
			HWND hwndEditText;
			switch(pBuffer[5]){//��ʾ���ǵڎ�·
			case 0:
				hwndEditText=::GetDlgItem(AfxGetMainWnd()->m_hWnd,IDC_EDIT_T1);											
				::SetWindowText(hwndEditText,iRebackStr);
				break;
			case 1:
				hwndEditText=::GetDlgItem(AfxGetMainWnd()->m_hWnd,IDC_EDIT_T2);											
				::SetWindowText(hwndEditText,iRebackStr);
				break;
			case 2:
				hwndEditText=::GetDlgItem(AfxGetMainWnd()->m_hWnd,IDC_EDIT_T3);											
				::SetWindowText(hwndEditText,iRebackStr);
				break;
			case 3:
				hwndEditText=::GetDlgItem(AfxGetMainWnd()->m_hWnd,IDC_EDIT_T4);											
				::SetWindowText(hwndEditText,iRebackStr);
				break;
			}
		}
	}
}
void CTest7660ModuleDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTest7660ModuleDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}

}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.

HCURSOR CTest7660ModuleDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}
/*
	���ڵĲ����ʿ������ã���������ȴû���������ã���Ҫ����Ĭ�ϵķ�ʽ
	Ĭ�Ϸ�ʽ��
	1���˿�  1
	2��У�鷽ʽ����У��
	3������λ����8λ		
	4��ֹͣλ 1λ
*/
void CTest7660ModuleDlg::OnBtnOpenPC() //�򿪴���֮ǰ�������¼�����ע��
{	//��һ�׶�Ŀ��		
	cSerialPort.RegDataReadCallback(ExtraDataFromBufferCallBack,NULL);
	//pc�����ں�+������ 
	CString snStr,pcBrStr;
	GetDlgItemText(IDC_COMBO_SP,snStr);        //pc�����ں�
	GetDlgItemText(IDC_COMBO_PCBR,pcBrStr);	   //pc��������    
	int length=snStr.GetLength();			
	if(!IsDataTypeInput(snStr,snStr.GetLength())){
		AfxMessageBox("���ں������������������룡");	
		return;
	}
	//����pc���Ĳ�����
	cSerialPort.SetBaudRate(atoi(pcBrStr));  
	//����pc�����ں�
	cSerialPort.SetPortIndex(atoi(snStr));
	/*�򿪴��ڴ�ʱ�ͻ��и�����������ִ�У�ÿ�������ݷ����ͻ��л���������*/
    int success=cSerialPort.OpenComm();
	if(success)    
		AfxMessageBox("����"+snStr+"�򿪳ɹ���");
	else
	{
		CString message="pc����"+snStr+"��ʧ�ܣ�����������pc���ڣ�";
		AfxMessageBox(message);
	}
}


void CTest7660ModuleDlg::OnButtonSet7660() 
{
	CString br7660,sn7660;
	GetDlgItemText(IDC_COMBO_7660BR,br7660);
	GetDlgItemText(IDC_COMBO_7660SN,sn7660);
	int br=atoi(br7660);
	BYTE baudRate;
	if(br==9600)
		baudRate=48;
	else
		baudRate=49;
	int sn=atoi(sn7660);
	BYTE order[8];
	order[0]=64;//@
	order[1]=48;//0
	order[2]=48;//0
	order[3]=87;//w
	order[4]=57;//9
	order[5]=((sn/10) % 10)+48;
	order[6]=(sn % 10)+48;
	order[7]=baudRate;
	BOOL success=cSerialPort.SendBuffer(order,8);
	if(success)
		AfxMessageBox("7660�����ʡ�վ�����óɹ���");
	else{
		AfxMessageBox("7660�����ʡ�վ������ʧ�ܣ�");		
	}		
}
//�ɼ����ã���˫��+���棩
void CTest7660ModuleDlg::OnBtnClt() 
{
	BYTE adByte[6];	
	memset(adByte,'\0',6);
    int adData=2*m_Radio_G1+m_Radio_Sp;
	adByte[0]=64;//@
	adByte[1]=48;//0
	adByte[2]=48;//0
	adByte[3]=87;//w
	adByte[4]=54;//6
	adByte[6]=adData;//������
    BOOL success=cSerialPort.SendBuffer(adByte,6);	
	if(success)
		AfxMessageBox("���óɹ���");
	else
		AfxMessageBox("����ʧ�ܣ�");
}

void CTest7660ModuleDlg::OnRadioG1() 
{
	m_Radio_G1=0;	
}

void CTest7660ModuleDlg::OnRadioG10() 
{
	m_Radio_G1=1;	
}

void CTest7660ModuleDlg::OnRadioG100() 
{
	m_Radio_G1=2;
}

void CTest7660ModuleDlg::OnRadioT() 
{
	m_Radio_Type=0;
}

void CTest7660ModuleDlg::OnRadioTa() 
{
	m_Radio_Type=1;
}

void CTest7660ModuleDlg::OnRadioTb() 
{
	m_Radio_Type=2;
}

void CTest7660ModuleDlg::OnRadioS() 
{
	m_Radio_S=0;
}

void CTest7660ModuleDlg::OnRadioTen() 
{
	m_Radio_S=1;
}

void CTest7660ModuleDlg::OnRadioFive() 
{
	m_Radio_S=2;
}

void CTest7660ModuleDlg::OnRadioNfive() 
{	
	m_Radio_S=3;
}

void CTest7660ModuleDlg::OnRadioSp() 
{	
	m_Radio_Sp=0;
}

void CTest7660ModuleDlg::OnRadioDp() 
{	
	m_Radio_Sp=1;	
}
void CTest7660ModuleDlg::SetHours(int iHours)
{
	if(iHours<0)
		return;
	m_iHours=iHours;
}
void CTest7660ModuleDlg::SetMinutes(int iMinutes)
{
	if(iMinutes<0 || iMinutes>59)
		return;
	m_iMinutes=iMinutes;
}
void CTest7660ModuleDlg::SetSeconds(int iSeconds)
{
	if(iSeconds<0 || iSeconds>59)
		return;
	m_iSeconds=iSeconds;
}

int CTest7660ModuleDlg::GetHours()
{
	return m_iHours;
}
int CTest7660ModuleDlg::GetMinutes()
{
	return m_iMinutes;
}
int CTest7660ModuleDlg::GetSeconds()
{
	return m_iSeconds;
}
void CTest7660ModuleDlg::ResetComboBox(int cIndex)
{
	switch(cIndex){
	case 0:
		m_cbC1.SetCurSel(0);
		break;
	case 1:
		m_cbC2.SetCurSel(0);
		break;
	case 2:
		m_cbC3.SetCurSel(0);
		break;
	case 3:
		m_cbC4.SetCurSel(0);
		break;
	}	
}
BOOL SendData(CString daDataStr,int iIndex)
{
	int daData=atoi(daDataStr);
	BYTE daByte[8];
	memset(daByte,'\0',8);
	daByte[0]=64;//@
	daByte[1]=48;//0
	daByte[2]=48;//0
	daByte[3]=87;//W
	daByte[4]=56;//8
	daByte[5]=iIndex;
	daByte[6]=((daData/256) % 256);
	daByte[7]=daData % 256;
	int uiLen=8;
	BOOL success=cSerialPort.SendBuffer(daByte,uiLen);
	if(!success){	
		return FALSE;
	}	
	return TRUE;
}
//������Ĳ���ת��Ϊ��ֵ�Ͳ����м���
bool CTest7660ModuleDlg::SelChangeComboC(CString cStr,int cIndex)
{	
	/*cEIndexö�e��ȫ��׃��*/
	//cEIndex=cIndex;
	int daData=atoi(cStr); 
	if(daData<0 || daData>4095){
		AfxMessageBox("������0-4095��ģ�������");
		ResetComboBox(cIndex);
		return false;
	}
	BYTE daByte[8];
	memset(daByte,'\0',8);
	daByte[0]=64;//@
	daByte[1]=48;//0
	daByte[2]=48;//0
	daByte[3]=87;//w
	daByte[4]=56;//8
	daByte[5]=cIndex;
	daByte[6]=((daData/256) % 256);
	daByte[7]=daData % 256;
	BOOL success=cSerialPort.SendBuffer(daByte,8);
	if(!success){
		ResetComboBox(cIndex);
		//AfxMessageBox("ģ�����ʧ�ܣ�");
		return false;
	}	
	return true;
}
void CTest7660ModuleDlg::OnSelchangeComboC1() 
{
	//��ֹ���ַ���ֵ�����ݵĳ���
	
	CString strC1;	   
	m_cbC1.GetLBText(m_cbC1.GetCurSel(),strC1);
	//AfxMessageBox(strC1);
	SelChangeComboC(strC1,0);
}

void CTest7660ModuleDlg::OnSelchangeComboC2() 
{
	CString strC2;	
	m_cbC2.GetLBText(m_cbC2.GetCurSel(),strC2);
	SelChangeComboC(strC2,1);
}

void CTest7660ModuleDlg::OnSelchangeComboC3() 
{
	CString strC3;
	m_cbC3.GetLBText(m_cbC3.GetCurSel(),strC3);
	SelChangeComboC(strC3,2);
}

void CTest7660ModuleDlg::OnSelchangeComboC4() 
{	
	CString strC4;	
	m_cbC4.GetLBText(m_cbC4.GetCurSel(),strC4);
	SelChangeComboC(strC4,3);
}

void CTest7660ModuleDlg::OnEditchangeComboC1()
{	
	CString channelStr;
	GetDlgItemText(IDC_COMBO_C1,channelStr);
	if(0==channelStr.GetLength())
		return;
	if(!IsDataTypeInput(channelStr,channelStr.GetLength())){
		AfxMessageBox("�Ƿ����룡");
		return;
	}
	SelChangeComboC(channelStr,0);		
}

void CTest7660ModuleDlg::OnEditchangeComboC2() 
{
	CString channelStr;
	GetDlgItemText(IDC_COMBO_C2,channelStr);
	if(0==channelStr.GetLength())
		return;
	if(!IsDataTypeInput(channelStr,channelStr.GetLength())){
		AfxMessageBox("�Ƿ����룡");
		return;
	}
	SelChangeComboC(channelStr,1);
}



void CTest7660ModuleDlg::OnEditchangeComboC3() 
{
	CString channelStr;
	GetDlgItemText(IDC_COMBO_C3,channelStr);
	if(0==channelStr.GetLength())
		return;
	if(!IsDataTypeInput(channelStr,channelStr.GetLength())){
		AfxMessageBox("�Ƿ����룡");
		return;
	}
	SelChangeComboC(channelStr,2);
}

void CTest7660ModuleDlg::OnEditchangeComboC4() 
{
	CString channelStr;
	GetDlgItemText(IDC_COMBO_C4,channelStr);
	if(0==channelStr.GetLength())
		return;
	if(!IsDataTypeInput(channelStr,channelStr.GetLength())){
		AfxMessageBox("�Ƿ����룡");
		return;
	}
	SelChangeComboC(channelStr,3);
}

BOOL CTest7660ModuleDlg::IsDataTypeInput(const CString &strInput,int length)
{
	int i=0;
	bool isDataInput=TRUE;		
	if(0==length)
		isDataInput=FALSE;
	while(i<length){
		if(strInput[i]<'0' || strInput[i]>'9'){
			isDataInput=false;
			break;
		}
		i++;
	}
	return isDataInput;
}
/*
	Ӧ����������������������1��ͣ
*/
void CTest7660ModuleDlg::OnBTNDurTest() 
{	
	cSerialPort.StopThread(FALSE);
	CString dayStr,comboStr1,comboStr2;
	GetDlgItemText(IDC_COMBO_TS,dayStr);	
	if(!IsDataTypeInput(dayStr,dayStr.GetLength())){
		AfxMessageBox("�������������������������룡");
		return;
	}		
	GetDlgItemText(IDC_COMBO_C1,comboStr1);	
	GetDlgItemText(IDC_COMBO_C2,comboStr2);
	if(0==comboStr1.GetLength()){
		AfxMessageBox("������ģ�����ͨ��1��ֵ!");
		return;
	}
	if(0==comboStr2.GetLength()){
		AfxMessageBox("������ģ�����ͨ��2��ֵ!");
		return;
	}    	
	
	if(INVALID_HANDLE_VALUE ==cSerialPort.GetHComm()){
		AfxMessageBox("����û�д򿪣�");
		return;
	}
	int day=atoi(dayStr);
	int aDayHours=24;
	int hours=day*aDayHours;
	StartTest(hours);
}
void LaserThreadFunc()
{	
	CString daData0="0";
	//Ĭ��ֵ��819
	const int MaxStrLength=10;
	CString daDataStr1="0",daDataStr2="0";
	char chsDataStr1[MaxStrLength];
	char chsDataStr2[MaxStrLength];
	CWnd *myWnd=AfxGetMainWnd();
	HWND comboHwnd1=::GetDlgItem(myWnd->m_hWnd,IDC_COMBO_C1);
	HWND comboHwnd2=::GetDlgItem(myWnd->m_hWnd,IDC_COMBO_C2);			
	::GetWindowText(comboHwnd1,chsDataStr1,MaxStrLength);
	::GetWindowText(comboHwnd2,chsDataStr2,MaxStrLength);
	daDataStr1.Format("%s",chsDataStr1);
	daDataStr2.Format("%s",chsDataStr2);
	
	CString daDataStr;
	int iIndex=0;
	while(m_bRun)
	{	
		if(iIndex==0)
			daDataStr=daDataStr1;
		else
			daDataStr=daDataStr2;

		if(!SendData(daDataStr,iIndex))
			return;
		Sleep(1000);//˯��1����
		if(!SendData(daData0,iIndex))
			return;	
		Sleep(1000);
		iIndex=(iIndex + 1)%2;
	}	
}
void CTest7660ModuleDlg::CloseLaser()
{
	CString daDateStr="0";
	SendData(daDateStr,1);
	
	SendData(daDateStr,0);
}
/*
	�����ú������򿪺��̼���
*/
void CTest7660ModuleDlg::StartTest(int hours)
{
	SetHours(hours);
	SetMinutes(0);
	SetSeconds(0);		

	hThread=CreateThread(NULL,
		0,
		(LPTHREAD_START_ROUTINE)LaserThreadFunc,/*�������LPTHREAD_START_ROUTINE ����ǿ��ת��������Ҫ��LaserThreadFunc����ΪWINAPI*/
		NULL,
		0,
		&ThreadID);

	SetTimer(IDTIMER,1000,0);	
}
/*
	Ĭ�ϵļ�ʱ����Ӧ����
*/
void CTest7660ModuleDlg::OnTimer(UINT nIDEvent) 
{
	const int MaxMS=59;
	if(m_bBegin){
		m_bBegin=false;
		m_iHours--;
		m_iMinutes=MaxMS;
		m_iSeconds=MaxMS;
	}
	else{		
		if(m_iSeconds==0){						
			if(m_iMinutes==0){
				if(m_iHours==0){
					KillTimer(IDTIMER);
					m_bRun=FALSE;
					CloseHandle(hThread);//?????????????????????????
					CloseLaser();					
					return;
				}
				else{
					m_iMinutes=MaxMS;
					m_iSeconds=MaxMS;
					m_iHours--;
				}				
			}
			else{
				m_iSeconds=MaxMS;
				m_iMinutes--;
			}
		}
		else
			m_iSeconds--;		
	}
	CString hoursStr,minutesStr,secondsStr,timeStr;
	if(m_iHours<10)
		hoursStr.Format("0%i",m_iHours);
	else
		hoursStr.Format("%i",m_iHours);

	if(m_iMinutes<10)
		minutesStr.Format("0%i",m_iMinutes);
	else
		minutesStr.Format("%i",m_iMinutes);

	if(m_iSeconds<10)
		secondsStr.Format("0%i",m_iSeconds);
	else
		secondsStr.Format("%i",m_iSeconds);

	timeStr="����ʱ��"+hoursStr+"��ʱ "+minutesStr+"���� "+secondsStr+"����";

	GetDlgItem(IDC_BTN_Dur_Test)->SetWindowText(timeStr);
	CDialog::OnTimer(nIDEvent);
}

void CTest7660ModuleDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	CloseLaser();
	Sleep(200);
	KillTimer(IDTIMER);
	m_bRun=FALSE;		
}
