#if !defined(AFX_TIMESELDLG_H__A425040A_BD23_4C10_B594_8782C9C07A00__INCLUDED_)
#define AFX_TIMESELDLG_H__A425040A_BD23_4C10_B594_8782C9C07A00__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// TimeSelDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// TimeSelDlg dialog

class TimeSelDlg : public CDialog
{
// Construction
public:
	TimeSelDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(TimeSelDlg)
	enum { IDD = IDD_DIALOG1 };
	CComboBox	m_cbTS;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(TimeSelDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(TimeSelDlg)
	afx_msg void OnBtnSure();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TIMESELDLG_H__A425040A_BD23_4C10_B594_8782C9C07A00__INCLUDED_)
