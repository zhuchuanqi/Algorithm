// TimeSelectDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Test7660Module.h"
#include "TimeSelectDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// TimeSelectDlg dialog


TimeSelectDlg::TimeSelectDlg(CWnd* pParent /*=NULL*/)
	: CDialog(TimeSelectDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(TimeSelectDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_TimeSelect.SetCurSel(6);
	UpdateData(false);
}


void TimeSelectDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(TimeSelectDlg)
	DDX_Control(pDX, IDC_COMBO_TS, m_TimeSelect);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(TimeSelectDlg, CDialog)
	//{{AFX_MSG_MAP(TimeSelectDlg)
	ON_BN_CLICKED(IDC_BTN_SURE, OnBtnSure)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// TimeSelectDlg message handlers

void TimeSelectDlg::OnBtnSure() 
{
	// TODO: Add your control notification handler code here
	CString dayStr;
	GetDlgItemText(IDC_COMBO_TS,dayStr);
	int i=0;
	bool canTrans=true;
	int length=dayStr.GetLength();		
	if(0==length)
		canTrans=false;
	while(i<length){
		if(dayStr[i]<'0' || dayStr[i]>'9'){
			canTrans=false;
			break;
		}
		i++;
	}
	if(!canTrans){
		AfxMessageBox("�������������������������룡");
		return;
	}	
	int day=atoi(dayStr);
	AfxMessageBox(dayStr);
}
